const dailySales = [
  { day: "Mon", amount: 2400 },
  { day: "Tue", amount: 1800 },
  { day: "Wed", amount: 3200 },
  { day: "Thu", amount: 2800 },
  { day: "Fri", amount: 3800 },
  { day: "Sat", amount: 4200 },
  { day: "Sun", amount: 3600 },
];

export default dailySales;
