const salesData = [
  { month: "Jan", sales: 12000, installments: 8000 },
  { month: "Feb", sales: 15000, installments: 9500 },
  { month: "Mar", sales: 18000, installments: 11000 },
  { month: "Apr", sales: 22000, installments: 13500 },
  { month: "May", sales: 19000, installments: 12000 },
  { month: "Jun", sales: 25000, installments: 15000 },
];

export default salesData;
