  const recentSales = [
    {
      id: "1",
      customer: "John Doe",
      amount: 1200,
      type: "cash",
      date: "2025-01-21",
    },
    {
      id: "2",
      customer: "Jane Smith",
      amount: 2500,
      type: "installment",
      date: "2025-01-21",
    },
    {
      id: "3",
      customer: "Mike Johnson",
      amount: 800,
      type: "cash",
      date: "2025-01-20",
    },
    {
      id: "4",
      customer: "Sarah Wilson",
      amount: 3200,
      type: "installment",
      date: "2025-01-20",
    },
  ];
export default recentSales;