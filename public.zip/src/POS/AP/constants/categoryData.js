const categoryData = [
  { name: "Smartphones", value: 35 },
  { name: "Laptops", value: 25 },
  { name: "Audio", value: 20, },
  { name: "Accessories", value: 45 },
  { name: "Home Appliances", value: 5 },
  { name: "Bikes", value: 24 },
  { name: "Geezers", value: 10 },
  { name: "Solars", value: 20 },
];
export default categoryData;
