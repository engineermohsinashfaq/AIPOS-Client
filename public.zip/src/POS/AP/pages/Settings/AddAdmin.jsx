import React from 'react'

const AddAdmin = () => {
  return (
    <div>AddAdmin</div>
  )
}

export default AddAdmin