import React from "react";

const AllAdmins = () => {
  return <div>AllAdmins</div>;
};

export default AllAdmins;
