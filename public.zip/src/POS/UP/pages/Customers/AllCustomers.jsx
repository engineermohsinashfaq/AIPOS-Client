import React, { useState, useMemo, useEffect } from "react";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { X } from "lucide-react";
import SearchIcon from "@mui/icons-material/Search";
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";
import VisibilityIcon from "@mui/icons-material/Visibility";

// ✅ Robust Date Formatter that handles all date formats (same as purchase history)
const formatDateTime = (dateInput) => {
  if (!dateInput) return "—";

  try {
    let date;

    // Handle different date formats
    if (dateInput instanceof Date) {
      date = dateInput;
    } else if (typeof dateInput === "string") {
      // Try to parse the date string - handle multiple formats
      if (dateInput.includes("/")) {
        // Handle DD/MM/YYYY format
        const parts = dateInput.split(" ");
        const datePart = parts[0];
        const timePart = parts[1];

        if (datePart.includes("/")) {
          const [day, month, year] = datePart.split("/");
          if (timePart) {
            const [hours, minutes, seconds] = timePart.split(":");
            date = new Date(
              year,
              month - 1,
              day,
              hours || 0,
              minutes || 0,
              seconds || 0
            );
          } else {
            date = new Date(year, month - 1, day);
          }
        }
      } else {
        // Try standard Date parsing
        date = new Date(dateInput);
      }
    } else {
      date = new Date(dateInput);
    }

    // Check if date is valid
    if (isNaN(date.getTime())) {
      return "—";
    }

    const day = String(date.getDate()).padStart(2, "0");
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const year = date.getFullYear();
    const hours = String(date.getHours()).padStart(2, "0");
    const minutes = String(date.getMinutes()).padStart(2, "0");
    const seconds = String(date.getSeconds()).padStart(2, "0");

    return `${day}/${month}/${year} ${hours}:${minutes}:${seconds}`;
  } catch (error) {
    console.error("Date formatting error:", error);
    return "—";
  }
};

// ✅ Short Date for Display (Table) - More robust version
const formatShortDate = (dateString) => {
  if (!dateString) return "—";

  try {
    const fullDate = formatDateTime(dateString);
    if (fullDate === "—") return "—";

    // Extract just the date part (DD/MM/YYYY)
    return fullDate.split(" ")[0];
  } catch (error) {
    return "—";
  }
};

// ---
// The main component
// ---

export default function AllCustomers() {
  const [customers, setCustomers] = useState(() => {
    try {
      const raw = localStorage.getItem("all_customers_data");
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  });

  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("All");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isViewOpen, setIsViewOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [editing, setEditing] = useState(false);
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [customerToDelete, setCustomerToDelete] = useState(null);
  const [form, setForm] = useState({});
  const [originalCustomer, setOriginalCustomer] = useState(null); // Track original data
  const [formChanges, setFormChanges] = useState({}); // Track changes

  useEffect(() => {
    localStorage.setItem("all_customers_data", JSON.stringify(customers));
  }, [customers]);

  const filtered = useMemo(() => {
    let arr = customers.slice();
    if (query.trim()) {
      const q = query.toLowerCase();
      arr = arr.filter((c) =>
        [
          c.customerId,
          c.firstName,
          c.lastName,
          c.contact,
          c.cnic,
          c.city,
          c.address,
        ]
          .join(" ")
          .toLowerCase()
          .includes(q)
      );
    }
    if (statusFilter !== "All")
      arr = arr.filter((c) => c.status === statusFilter);
    arr.sort((a, b) => a.customerId.localeCompare(b.customerId));
    return arr;
  }, [customers, query, statusFilter]);

  // Check if form has been modified and track changes
  const isFormModified = useMemo(() => {
    if (!originalCustomer || !form) return false;

    const fieldsToCompare = [
      "firstName",
      "lastName",
      "contact",
      "cnic",
      "city",
      "address",
      "status",
    ];

    const changes = {};
    let hasChanges = false;

    fieldsToCompare.forEach((field) => {
      const originalValue = String(originalCustomer[field] || "").trim();
      const formValue = String(form[field] || "").trim();
      if (originalValue !== formValue) {
        changes[field] = {
          from: originalValue,
          to: formValue,
        };
        hasChanges = true;
      }
    });

    setFormChanges(changes);
    return hasChanges;
  }, [form, originalCustomer]);

  // ✅ Toast setup
  const toastConfig = {
    position: "top-right",
    theme: "dark",
    autoClose: 2000,
  };
  const notifySuccess = (msg) => toast.success(msg, toastConfig);
  const notifyError = (msg) => toast.error(msg, toastConfig);

  const initials = (c) =>
    `${(c.firstName || "").charAt(0)}${(c.lastName || "").charAt(
      0
    )}`.toUpperCase();

  // Function to get field display name
  const getFieldDisplayName = (field) => {
    const fieldNames = {
      firstName: "First Name",
      lastName: "Last Name",
      contact: "Contact",
      cnic: "CNIC",
      city: "City",
      address: "Address",
      status: "Status",
    };
    return fieldNames[field] || field;
  };

  const handleOpenEdit = (customer) => {
    setForm(customer);
    setOriginalCustomer(customer); // Set original data for comparison
    setFormChanges({});
    setEditing(true);
    setIsModalOpen(true);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;

    if (name === "contact") {
      let val = value.replace(/[^\d+]/g, "");
      if (val && val[0] !== "+") val = "+" + val.replace(/\+/g, "");
      setForm((s) => ({ ...s, contact: val }));
      return;
    }

    if (name === "cnic") {
      let digits = value.replace(/\D/g, "").slice(0, 13);
      let formatted = digits;
      if (digits.length > 5 && digits.length <= 12)
        formatted = `${digits.slice(0, 5)}-${digits.slice(5)}`;
      if (digits.length === 13)
        formatted = `${digits.slice(0, 5)}-${digits.slice(
          5,
          12
        )}-${digits.slice(12)}`;
      setForm((s) => ({ ...s, cnic: formatted }));
      return;
    }

    setForm((s) => ({ ...s, [name]: value }));
  };

  // ✅ Updated Save Handler with change detection
  const handleSave = (e) => {
    e.preventDefault();

    if (!form.firstName?.trim()) return notifyError("First name is required");
    if (!form.lastName?.trim()) return notifyError("Last name is required");
    if (!form.contact?.trim()) return notifyError("Contact number is required");
    if (!form.cnic?.trim()) return notifyError("CNIC is required");
    if (!/^\d{5}-\d{7}-\d{1}$/.test(form.cnic))
      return notifyError("Invalid CNIC format (e.g., 12345-6789012-3)");

    // Create update message with changed fields
    const changedFields = Object.keys(formChanges);
    const updateMessage =
      changedFields.length > 0
        ? `Updated: ${changedFields
            .map((field) => getFieldDisplayName(field))
            .join(", ")}`
        : "Record updated";

    // Add updated time and update message
    const updatedForm = {
      ...form,
      updatedAt: formatDateTime(new Date()),
      lastUpdateMessage: updateMessage,
    };

    setCustomers((prev) =>
      prev.map((c) => (c.customerId === form.customerId ? updatedForm : c))
    );
    setIsModalOpen(false);
    setOriginalCustomer(null); // Reset original customer
    setFormChanges({});
    notifySuccess(`${form.customerId} updated successfully.`);
  };

  const handleDelete = (customer) => {
    setCustomerToDelete(customer);
    setIsDeleteModalOpen(true);
  };

  const confirmDelete = () => {
    if (!customerToDelete) return;
    setCustomers((prev) =>
      prev.filter((c) => c.customerId !== customerToDelete.customerId)
    );
    notifySuccess(`Customer ${customerToDelete.customerId} deleted!`);
    setIsDeleteModalOpen(false);
    setCustomerToDelete(null);
  };

  const cancelDelete = () => {
    setCustomerToDelete(null);
    setIsDeleteModalOpen(false);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setOriginalCustomer(null); // Reset original customer when closing modal
    setFormChanges({});
  };

  const handlePrint = () => {
    const bodyOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    window.print();
    document.body.style.overflow = bodyOverflow;
  };

  return (
    <div className="p-2 min-h-screen text-white">
      <ToastContainer position="top-right" theme="dark" autoClose={2000} />

      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">All Customers</h1>
          <p className="text-white/80">
            View, edit, and manage customer accounts.
          </p>
        </div>

        {/* Filters */}
        <div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-md p-4 grid grid-cols-1 md:grid-cols-3 gap-3">
          <div className="flex items-center gap-2 rounded border border-white/10 bg-white/5 px-3 py-2 md:col-span-2">
            <SearchIcon className="text-white" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search"
              className="flex-1 outline-none bg-transparent text-white placeholder-white/60"
            />
          </div>

          <div className="flex items-center gap-2 justify-between md:justify-end">
            <label className="text-sm text-white/70">Status</label>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="p-2 border border-white/10 rounded bg-white/10 text-white"
            >
              <option className="bg-black/95 text-white">All</option>
              <option className="bg-black/95 text-white">Active</option>
              <option className="bg-black/95 text-white">Inactive</option>
              <option className="bg-black/95 text-white">Suspended</option>
            </select>
          </div>
        </div>

        {/* Table */}
        <div className="bg-white/5 backdrop-blur-lg border border-white/10 rounded-md overflow-x-auto scrollbar-hide ">
          <table className="w-full text-white/90 min-w-[900px]">
            <thead className="bg-white/10 text-left text-sm">
              <tr>
                <th className="p-3">ID</th>
                <th className="p-3">Name</th>
                <th className="p-3">CNIC</th>
                <th className="p-3">Contact</th>
                <th className="p-3">City</th>
                <th className="p-3">Status</th>
                <th className="p-3">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.length > 0 ? (
                filtered.map((c) => (
                  <tr
                    key={c.customerId}
                    className={`border-t border-white/15 transition
        hover:bg-green-500/50
        ${
          c.status === "Inactive"
            ? "hover:bg-yellow-500/50"
            : c.status === "Suspended"
            ? "hover:bg-red-500/50"
            : ""
        }`}
                  >
                    <td className="p-3">{c.customerId}</td>
                    <td className="p-3 flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center">
                        <span className="font-medium text-white">
                          {initials(c)}
                        </span>
                      </div>
                      <div>
                        <div className="font-medium text-white">
                          {c.firstName} {c.lastName}
                        </div>
                      </div>
                    </td>
                    <td className="p-3">{c.cnic}</td>
                    <td className="p-3">{c.contact}</td>
                    <td className="p-3">{c.city}</td>
                    <td className="p-3">{c.status}</td>
                    <td className="p-3 flex gap-2">
                      <button
                        title="View"
                        onClick={() => {
                          setSelectedCustomer(c);
                          setIsViewOpen(true);
                        }}
                        className="p-2 rounded bg-cyan-900 text-white hover:bg-cyan-950 transition-colors cursor-pointer"
                      >
                        <VisibilityIcon fontSize="small" />
                      </button>
                      <button
                        title="Edit"
                        onClick={() => handleOpenEdit(c)}
                        className="p-2 rounded bg-yellow-400 text-gray-900 hover:bg-yellow-300 transition-colors cursor-pointer"
                      >
                        <EditIcon fontSize="small" />
                      </button>
                      <button
                        title="Delete"
                        onClick={() => handleDelete(c)}
                        className="p-2 rounded bg-red-600 text-white hover:bg-red-700 transition-colors cursor-pointer"
                      >
                        <DeleteIcon fontSize="small" />
                      </button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="7" className="text-center py-6 text-white/60">
                    {customers.length === 0
                      ? "No customers added yet."
                      : "No customers match your search."}
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* ✅ Edit Modal with Change Detection */}
      {isModalOpen && (
        <div className="fixed inset-0 flex items-center justify-center bg-black/30 z-50 backdrop-blur-md">
          <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-lg p-6 w-full max-w-lg text-white">
            <h2 className="text-xl font-semibold mb-4">
              Edit Customer: {form.customerId}
            </h2>

            {/* Display changes summary */}
            {isFormModified && (
              <div className="mb-4 p-2 bg-yellow-500/20 border border-yellow-500/30 rounded">
                <p className="font-medium text-yellow-300">Changes detected:</p>
                <ul className="text-xs mt-1 space-y-1">
                  {Object.entries(formChanges).map(([field, change]) => (
                    <li key={field} className="flex justify-between">
                      <span>{getFieldDisplayName(field)}:</span>
                      <span className="text-yellow-200">
                        "{change.from}" → "{change.to}"
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            <form onSubmit={handleSave} className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <input
                  name="firstName"
                  value={form.firstName}
                  onChange={handleChange}
                  placeholder="First Name"
                  className="p-2 rounded bg-black/30 border border-white/20 outline-none"
                />
                <input
                  name="lastName"
                  value={form.lastName}
                  onChange={handleChange}
                  placeholder="Last Name"
                  className="p-2 rounded bg-black/30 border border-white/20 outline-none"
                />
              </div>
              <input
                name="contact"
                value={form.contact}
                onChange={handleChange}
                placeholder="Contact (+92...)"
                className="w-full p-2 rounded bg-black/30 border border-white/20 outline-none"
              />
              <input
                name="cnic"
                value={form.cnic}
                onChange={handleChange}
                placeholder="CNIC"
                className="w-full p-2 rounded bg-black/30 border border-white/20 outline-none"
              />
              <input
                name="city"
                value={form.city}
                onChange={handleChange}
                placeholder="City"
                className="w-full p-2 rounded bg-black/30 border border-white/20 outline-none"
              />
              <input
                name="address"
                value={form.address || ""}
                onChange={handleChange}
                placeholder="Address"
                className="w-full p-2 rounded bg-black/30 border border-white/20 outline-none"
              />
              <select
                name="status"
                value={form.status}
                onChange={handleChange}
                className="w-full p-2 rounded bg-black/30 border border-white/20 outline-none"
              >
                <option className="bg-black/90">Active</option>
                <option className="bg-black/90">Inactive</option>
                <option className="bg-black/90">Suspended</option>
              </select>

              <div className="flex justify-end gap-3 pt-4">
                <button
                  type="submit"
                  disabled={!isFormModified}
                  className={`px-4 py-2 rounded border border-white/40 transition hover:cursor-pointer ${
                    isFormModified
                      ? "bg-cyan-800/80 hover:bg-cyan-900"
                      : "bg-gray-600/50 cursor-not-allowed opacity-50"
                  }`}
                >
                  Save Changes
                </button>
                <button
                  type="button"
                  onClick={handleCloseModal}
                  className="px-4 py-2 rounded border border-white/40 bg-red-600 hover:bg-red-700 transition hover:cursor-pointer"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ✅ View Modal */}
      {isViewOpen && selectedCustomer && (
        <div className="fixed inset-0 flex items-center justify-center bg-black/30 z-50 p-2 md:p-4 backdrop-blur-md print:p-0">
          <div className="bg-white text-black rounded-lg w-full max-w-md mx-auto max-h-[95vh] overflow-y-auto scrollbar-hide relative font-sans text-sm border border-gray-300">
            {/* Content */}
            <div className="p-4 space-y-3">
              {/* Company Header */}
              <div className="text-center border-b border-dashed border-gray-300 pb-3 mb-3">
                <h2 className="text-xl font-bold tracking-wider text-gray-900">
                  ZUBI ELECTRONICS
                </h2>
                <p className="text-sm text-gray-600 mt-1">
                  Customer Information
                </p>
                <div className="mt-2 space-y-1">
                  <p className="text-xs font-semibold text-gray-700">
                    Customer ID: {selectedCustomer.customerId}
                  </p>
                </div>
              </div>

              {/* Customer Information */}
              <div className="space-y-3">
                <div className="grid grid-cols-2 gap-2">
                  <span className="font-medium text-gray-700">First Name:</span>
                  <span className="text-gray-900 text-right">
                    {selectedCustomer.firstName}
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <span className="font-medium text-gray-700">Last Name:</span>
                  <span className="text-gray-900 text-right">
                    {selectedCustomer.lastName}
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <span className="font-medium text-gray-700">Contact:</span>
                  <span className="text-gray-900 text-right">
                    {selectedCustomer.contact}
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <span className="font-medium text-gray-700">CNIC:</span>
                  <span className="text-gray-900 text-right">
                    {selectedCustomer.cnic}
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <span className="font-medium text-gray-700">City:</span>
                  <span className="text-gray-900 text-right">
                    {selectedCustomer.city}
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <span className="font-medium text-gray-700">Address:</span>
                  <span className="text-gray-900 text-right">
                    {selectedCustomer.address || "—"}
                  </span>
                </div>
              </div>

              {/* Status Highlight */}
              <div
                className={`rounded-md p-2 mt-3 ${
                  selectedCustomer.status === "Active"
                    ? "bg-green-200 border border-green-300"
                    : selectedCustomer.status === "Inactive"
                    ? "bg-yellow-200 border border-yellow-300"
                    : "bg-red-200 border border-red-300"
                }`}
              >
                <div className="grid grid-cols-2 gap-2">
                  <span
                    className={`font-bold ${
                      selectedCustomer.status === "Active"
                        ? "text-green-900"
                        : selectedCustomer.status === "Inactive"
                        ? "text-yellow-900"
                        : "text-red-900"
                    }`}
                  >
                    Account Status:
                  </span>
                  <span
                    className={`font-bold text-right ${
                      selectedCustomer.status === "Active"
                        ? "text-green-900"
                        : selectedCustomer.status === "Inactive"
                        ? "text-yellow-900"
                        : "text-red-900"
                    }`}
                  >
                    {selectedCustomer.status}
                  </span>
                </div>
              </div>

              {/* Dates */}
              <div className="text-xs text-gray-500 italic border-t border-dashed border-gray-300 pt-3 mt-3">
                <div className="grid grid-cols-2 gap-2">
                  <span>Date Added:</span>
                  <span className="text-right">
                    {formatDateTime(selectedCustomer.dateAdded)}
                  </span>
                </div>
                {selectedCustomer.updatedAt && (
                  <div className="grid grid-cols-2 gap-2 mt-1">
                    <span>Last Updated:</span>
                    <span className="text-right">
                      {formatDateTime(selectedCustomer.updatedAt)}
                    </span>
                  </div>
                )}
                {selectedCustomer.lastUpdateMessage && (
                  <div className="col-span-2 mt-2 p-2 bg-yellow-100 border border-yellow-300 rounded text-yellow-800">
                    <span className="font-medium">Update Note: </span>
                    {selectedCustomer.lastUpdateMessage}
                  </div>
                )}
              </div>

              {/* Footer */}
              <div className="text-center border-t border-dashed border-gray-300 pt-4 text-xs text-gray-600">
                <p>This is a computer-generated customer record.</p>
                <p>Contains personal and contact information only.</p>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="sticky bottom-0 bg-white border-t border-gray-200 rounded-b-lg p-2 print:hidden">
              <div className="flex flex-col sm:flex-row gap-2 justify-end">
                <button
                  onClick={handlePrint}
                  className="px-4 py-2 rounded bg-blue-600 cursor-pointer text-white hover:bg-blue-700 transition font-medium flex items-center justify-center gap-2"
                >
                  <span>🖨️</span>
                  <span>Print</span>
                </button>
                <button
                  onClick={() => setIsViewOpen(false)}
                  className="px-4 py-2 rounded bg-gray-600 cursor-pointer text-white hover:bg-gray-700 transition font-medium"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ✅ Delete Modal */}
      {isDeleteModalOpen && customerToDelete && (
        <div className="fixed inset-0 flex items-center justify-center bg-black/30 z-50 backdrop-blur-md">
          <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-lg p-6 w-full max-w-sm text-white">
            <h2 className="text-xl font-semibold mb-4">Confirm Delete</h2>
            <p className="mb-4">
              Are you sure you want to delete{" "}
              <strong>
                {customerToDelete.firstName} {customerToDelete.lastName}
              </strong>
              ?
            </p>
            <div className="flex justify-end gap-3">
              <button
                onClick={cancelDelete}
                className="px-4 py-2 rounded border border-white/40 bg-cyan-800/80 hover:bg-cyan-900 hover:cursor-pointer transition"
              >
                Cancel
              </button>
              <button
                onClick={confirmDelete}
                className="px-4 py-2 rounded border border-white/40 bg-red-600 hover:bg-red-700 hover:cursor-pointer transition"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
