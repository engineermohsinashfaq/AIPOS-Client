import React, { useState, useMemo, useEffect } from "react";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import SearchIcon from "@mui/icons-material/Search";
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";
import VisibilityIcon from "@mui/icons-material/Visibility";
import CloseIcon from "@mui/icons-material/Close";

const sampleCustomers = [
  {
    customerId: "C-001",
    firstName: "Alice",
    lastName: "Johnson",
    contact: "+923001234567",
    cnic: "12345-1234567-1",
    city: "New York",
    address: "123 Main St",
    status: "Active",
    dateAdded: new Date().toISOString(),
  },
  {
    customerId: "C-002",
    firstName: "Bob",
    lastName: "Smith",
    contact: "+923009876543",
    cnic: "54321-7654321-0",
    city: "Los Angeles",
    address: "456 Market St",
    status: "Inactive",
    dateAdded: new Date().toISOString(),
  },
];

// ✅ Utility for date formatting
const formatDateWithMonth = (dateString) => {
  const date = new Date(dateString);
  const options = { year: "numeric", month: "long", day: "numeric" };
  return date.toLocaleDateString(undefined, options);
};

export default function AllCustomers() {
  const [customers, setCustomers] = useState(() => {
    try {
      const raw = localStorage.getItem("all_customers_data");
      return raw ? JSON.parse(raw) : sampleCustomers;
    } catch {
      return sampleCustomers;
    }
  });

  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("All");
  const [selectedCustomer, setSelectedCustomer] = useState(null);

  useEffect(() => {
    localStorage.setItem("all_customers_data", JSON.stringify(customers));
  }, [customers]);

  const filteredCustomers = useMemo(() => {
    let arr = customers.slice();
    if (query.trim()) {
      const q = query.toLowerCase();
      arr = arr.filter((c) =>
        [c.customerId, c.firstName, c.lastName, c.contact, c.cnic, c.city, c.address]
          .join(" ")
          .toLowerCase()
          .includes(q)
      );
    }
    if (statusFilter !== "All") {
      arr = arr.filter((c) => c.status === statusFilter);
    }
    return arr;
  }, [customers, query, statusFilter]);

  const handleDelete = (id) => {
    setCustomers((prev) => prev.filter((c) => c.customerId !== id));
    toast.success("Customer deleted successfully!");
  };

  const handlePrint = () => {
    const bodyOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    window.print();
    document.body.style.overflow = bodyOverflow;
  };

  return (
    <div className="p-4 min-h-[95vh] text-white">
      <ToastContainer />
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Heading */}
        <div>
          <h1 className="text-3xl font-bold mb-2">All Customers</h1>
          <p className="text-white/80">View all customers and their details.</p>
        </div>

        {/* Filters */}
        <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-xl p-4 flex flex-col md:flex-row gap-4 items-center justify-between">
          <div className="flex items-center gap-2 bg-black/30 p-2 rounded max-w-[90%]">
            <SearchIcon />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search"
              className="bg-transparent outline-none text-white"
            />
          </div>
          <div className="flex items-center gap-2">
            <label>Status:</label>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="p-2 bg-black/30 border border-white/20 rounded text-white"
            >
              <option className="bg-black/90">All</option>
              <option className="bg-black/90">Active</option>
              <option className="bg-black/90">Inactive</option>
              <option className="bg-black/90">Suspended</option>
            </select>
          </div>
        </div>

        {/* Customers Table */}
        <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-xl overflow-x-auto">
          <table className="w-full text-white min-w-[900px]">
            <thead className="bg-white/20 text-left text-sm">
              <tr>
                <th className="p-3">ID</th>
                <th className="p-3">Name</th>
                <th className="p-3">Contact</th>
                <th className="p-3">CNIC</th>
                <th className="p-3">City</th>
                <th className="p-3">Address</th>
                <th className="p-3">Status</th>
                <th className="p-3">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredCustomers.map((c) => (
                <tr
                  key={c.customerId}
                  className="border-t border-white/10 hover:bg-white/10"
                >
                  <td className="p-3">{c.customerId}</td>
                  <td className="p-3">{c.firstName} {c.lastName}</td>
                  <td className="p-3">{c.contact}</td>
                  <td className="p-3">{c.cnic}</td>
                  <td className="p-3">{c.city}</td>
                  <td className="p-3">{c.address}</td>
                  <td className="p-3">{c.status}</td>
                  <td className="p-3 flex gap-2">
                    <button
                      onClick={() => setSelectedCustomer(c)}
                      className="p-2 rounded bg-blue-600 hover:bg-blue-500 hover:cursor-pointer"
                    >
                      <VisibilityIcon fontSize="small" />
                    </button>
                    <button
                      onClick={() => toast.info("Edit functionality coming soon")}
                      className="p-2 rounded bg-yellow-400 text-black hover:bg-yellow-300 hover:cursor-pointer"
                    >
                      <EditIcon fontSize="small" />
                    </button>
                    <button
                      onClick={() => handleDelete(c.customerId)}
                      className="p-2 rounded bg-red-600 text-white hover:bg-red-700 hover:cursor-pointer"
                    >
                      <DeleteIcon fontSize="small" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* ✅ CUSTOMER DETAILS MODAL (same as POS/Guarantor modal) */}
      {selectedCustomer && (
        <div className="fixed inset-0 flex items-center justify-center bg-black/60 backdrop-blur-md z-50 p-2 sm:p-4">
          <div className="bg-white/10 border border-white/30 backdrop-blur-xl rounded-2xl w-full max-w-[95%] sm:max-w-[600px] h-[85vh] shadow-xl text-white relative flex flex-col print:w-full print:h-auto print:bg-white print:text-black print:overflow-visible">
            <button
              className="absolute top-3 right-3 hover:cursor-pointer print:hidden cursor-pointer"
              onClick={() => setSelectedCustomer(null)}
            >
              <CloseIcon />
            </button>

            <div className="flex-1 overflow-y-auto p-4 sm:p-7 space-y-4 scrollbar-hide print:p-5">
              <div className="text-center mb-6">
                <h1 className="text-2xl sm:text-3xl font-bold">ZUBI Electronics</h1>
                <p className="text-white/70 print:text-black text-sm sm:text-base">
                  Pakistan | 📞 +92 300 1358167
                </p>
                <hr className="border-white/30 my-4 print:border-black/40" />
                <h2 className="text-lg sm:text-xl font-semibold">CUSTOMER DETAILS</h2>
                
              </div>

              <div className="space-y-2 text-sm sm:text-base leading-relaxed">
                <p><strong>ID:</strong> {selectedCustomer.customerId}</p>
                <p><strong>Name:</strong> {selectedCustomer.firstName} {selectedCustomer.lastName}</p>
                <p><strong>Contact:</strong> {selectedCustomer.contact}</p>
                <p><strong>CNIC:</strong> {selectedCustomer.cnic}</p>
                <p><strong>City:</strong> {selectedCustomer.city}</p>
                <p><strong>Address:</strong> {selectedCustomer.address}</p>
                <p><strong>Status:</strong> {selectedCustomer.status}</p>
                <p><strong>Date Added:</strong> {formatDateWithMonth(selectedCustomer.dateAdded)}</p>
              </div>

              <div className="mt-8 text-center text-white/70 text-xs sm:text-sm print:text-black">
                <p>Thank you for being a valued customer of ZUBI Electronics.</p>
                <p className="text-white/50 mt-2 print:text-gray-600">
                  This is a computer-generated document.
                </p>
              </div>
            </div>

            <div className="p-3 sm:p-4 border-t border-white/20 flex flex-wrap justify-center gap-2 print:hidden">
              <button
                onClick={() => toast.success("Customer details saved successfully!")}
                className="bg-green-700 hover:bg-green-600 px-3 sm:px-4 py-2 rounded-md font-semibold cursor-pointer text-sm sm:text-base"
              >
                💾 Save
              </button>

              <button
                onClick={handlePrint}
                className="bg-blue-700 hover:bg-blue-600 px-3 sm:px-4 py-2 rounded-md font-semibold cursor-pointer text-sm sm:text-base"
              >
                🖨️ Print
              </button>

              <button
                onClick={() => setSelectedCustomer(null)}
                className="bg-red-700 hover:bg-red-600 px-3 sm:px-4 py-2 rounded-md font-semibold cursor-pointer text-sm sm:text-base"
              >
                ✖ Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
