import React, { useState, useEffect } from "react";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import AddIcon from "@mui/icons-material/Add";
import { useNavigate } from "react-router-dom";

// 🧩 Empty product template
const emptyProduct = {
  productId: "",
  invoiceId: "",
  name: "",
  model: "",
  category: "",
  company: "",
  price: "",
  quantity: "",
  supplier: "",
  supplierContact: "",
  total: "",
  value: "",
};

// ✅ Product ID Generator
const generateProductId = () => {
  const existing = JSON.parse(localStorage.getItem("products") || "[]");
  const lastSavedId = existing.reduce((max, prod) => {
    const num = parseInt(prod.productId?.replace("P-", ""), 10);
    return !isNaN(num) && num > max ? num : max;
  }, 0);
  const nextId = lastSavedId + 1;
  return `P-${String(nextId).padStart(3, "0")}`;
};

// ✅ Improved Invoice ID Generator
const generateInvoiceId = () => {
  const existingProducts = JSON.parse(localStorage.getItem("products") || "[]");
  const existingHistory = JSON.parse(localStorage.getItem("purchaseHistory") || "[]");
  const allInvoices = [...existingProducts, ...existingHistory]
    .map((item) => item.invoiceId)
    .filter((id) => id && id.startsWith("Inv-"));

  if (allInvoices.length === 0) return "Inv-001";

  const lastSavedNum = allInvoices.reduce((max, id) => {
    const num = parseInt(id.replace("Inv-", ""), 10);
    return !isNaN(num) && num > max ? num : max;
  }, 0);

  const nextNum = lastSavedNum + 1;
  return `Inv-${String(nextNum).padStart(3, "0")}`;
};

// 🧩 Load products from storage
const loadProducts = () => {
  const stored = localStorage.getItem("products");
  return stored ? JSON.parse(stored) : [];
};

// ✅ Robust Date Formatter that handles all date formats
const formatDateTime = (dateInput) => {
  if (!dateInput) return "—";
  
  try {
    let date;
    
    // Handle different date formats
    if (dateInput instanceof Date) {
      date = dateInput;
    } else if (typeof dateInput === 'string') {
      // Try to parse the date string - handle multiple formats
      if (dateInput.includes('/')) {
        // Handle DD/MM/YYYY format
        const parts = dateInput.split(' ');
        const datePart = parts[0];
        const timePart = parts[1];
        
        if (datePart.includes('/')) {
          const [day, month, year] = datePart.split('/');
          if (timePart) {
            const [hours, minutes, seconds] = timePart.split(':');
            date = new Date(year, month - 1, day, hours || 0, minutes || 0, seconds || 0);
          } else {
            date = new Date(year, month - 1, day);
          }
        }
      } else {
        // Try standard Date parsing
        date = new Date(dateInput);
      }
    } else {
      date = new Date(dateInput);
    }
    
    // Check if date is valid
    if (isNaN(date.getTime())) {
      return "—";
    }
    
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const year = date.getFullYear();
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    const seconds = String(date.getSeconds()).padStart(2, '0');
    
    return `${day}/${month}/${year} ${hours}:${minutes}:${seconds}`;
  } catch (error) {
    console.error('Date formatting error:', error);
    return "—";
  }
};

// ✅ Short Date for Display (Table) - More robust version
const formatShortDate = (dateString) => {
  if (!dateString) return "—";
  
  try {
    const fullDate = formatDateTime(dateString);
    if (fullDate === "—") return "—";
    
    // Extract just the date part (DD/MM/YYYY)
    return fullDate.split(' ')[0];
  } catch (error) {
    return "—";
  }
};

export default function AddPurchase({ onSave }) {
  const [product, setProduct] = useState(emptyProduct);
  const [products, setProducts] = useState(loadProducts());
  const navigate = useNavigate();

  // ⏳ Generate IDs on mount
  useEffect(() => {
    setProduct((prev) => ({
      ...prev,
      productId: generateProductId(),
      invoiceId: generateInvoiceId(),
    }));
  }, []);

  // 💰 Auto-calculate total
  useEffect(() => {
    const price = parseFloat(product.price) || 0;
    const qty = parseInt(product.quantity) || 0;
    const total = (price * qty).toFixed(2);
    setProduct((prev) => ({ ...prev, total, value: total }));
  }, [product.price, product.quantity]);

  // 📝 Handle form field changes
  const handleChange = (e) => {
    const { name, value } = e.target;

    if (name === "price") {
      setProduct((prev) => ({ ...prev, [name]: value.replace(/[^\d.]/g, "") }));
      return;
    }

    if (name === "quantity") {
      setProduct((prev) => ({ ...prev, [name]: value.replace(/\D/g, "") }));
      return;
    }

    if (name === "supplierContact") {
      let digits = value.replace(/\D/g, "").slice(0, 15);
      setProduct((prev) => ({ ...prev, [name]: digits }));
      return;
    }

    setProduct((prev) => ({ ...prev, [name]: value }));
  };

  // 💾 Handle form submit
  const handleSubmit = (e) => {
    e.preventDefault();
    const toastOptions = { theme: "dark", autoClose: 2000 };

    // Validation
    if (!/^P-\d+$/.test(product.productId))
      return toast.error("Invalid Product ID", toastOptions);
    if (!/^Inv-\d+$/.test(product.invoiceId))
      return toast.error("Invalid or missing Invoice ID", toastOptions);
    if (!product.name.trim())
      return toast.error("Name is required", toastOptions);
    if (!product.model.trim())
      return toast.error("Model is required", toastOptions);
    if (!product.category.trim())
      return toast.error("Category is required", toastOptions);
    if (!product.company.trim())
      return toast.error("Company is required", toastOptions);
    if (!product.price || parseFloat(product.price) <= 0)
      return toast.error("Valid Purchase Price required", toastOptions);
    if (!product.quantity || parseInt(product.quantity) <= 0)
      return toast.error("Valid Quantity required", toastOptions);
    if (!product.supplier.trim())
      return toast.error("Supplier is required", toastOptions);

    const fullSupplierContact = "+" + product.supplierContact;
    if (!/^\+\d{7,15}$/.test(fullSupplierContact))
      return toast.error(
        "Supplier Contact must start with '+' and 7–15 digits",
        toastOptions
      );

    if (
      products.some(
        (p) => p.model?.toLowerCase() === product.model.toLowerCase()
      )
    )
      return toast.error("Model must be unique!", toastOptions);

    // Save product with consistent timestamp
    const timestamp = formatDateTime(new Date());
    const newProduct = {
      ...product,
      supplierContact: fullSupplierContact,
      savedOn: timestamp,
      updatedOn: timestamp,
      type: "new-purchase"
    };

    const updatedProducts = [...products, newProduct];
    localStorage.setItem("products", JSON.stringify(updatedProducts));
    setProducts(updatedProducts);

    // Add to purchase history
    const existingHistory = JSON.parse(localStorage.getItem("purchaseHistory") || "[]");
    localStorage.setItem("purchaseHistory", JSON.stringify([...existingHistory, newProduct]));

    // ✅ Generate next invoice ID for next purchase
    const nextInvoiceId = generateInvoiceId();

    toast.success(`Product saved with Invoice ${product.invoiceId}`, {
      ...toastOptions,
      onClose: () => {
        setProduct({
          ...emptyProduct,
          productId: generateProductId(),
          invoiceId: nextInvoiceId,
        });
        navigate("/up-inventory");
      },
    });

    onSave?.(newProduct);
  };

  // 🧹 Clear form
  const handleClear = () => {
    setProduct((prev) => ({
      ...emptyProduct,
      productId: generateProductId(),
      invoiceId: generateInvoiceId(),
    }));
    toast.info("Form cleared", { theme: "dark", autoClose: 1500 });
  };

  return (
    <div className="px-4 py-2 min-h-[100%]">
      <ToastContainer theme="dark" autoClose={2000} />
      <div className="w-8xl mx-auto space-y-3">
        <div>
          <h1 className="text-3xl font-bold text-white">Add Purchase</h1>
          <p className="text-white/80">
            Fill in the product details below to record a purchase.
          </p>
        </div>

        <div className="bg-white/10 backdrop-blur-lg border border-white/20 rounded-xl p-4 text-white shadow-lg mt-6">
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* All fields in 2-column grid layout */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Invoice No */}
              <div>
                <label className="block mb-1 text-sm text-white/80">
                  Invoice No
                </label>
                <input
                  type="text"
                  name="invoiceId"
                  value={product.invoiceId}
                  readOnly
                  className="w-full p-3 rounded-md bg-black/40 border border-white/30 text-white outline-none cursor-not-allowed"
                />
              </div>

              {/* Product ID */}
              <div>
                <label className="block mb-1 text-sm text-white/80">
                  Product ID
                </label>
                <input
                  type="text"
                  name="productId"
                  value={product.productId}
                  readOnly
                  className="w-full p-3 rounded-md bg-black/40 border border-white/30 text-white outline-none cursor-not-allowed"
                />
              </div>

              {/* Name */}
              <div>
                <label
                  htmlFor="name"
                  className="block mb-1 text-sm text-white/80"
                >
                  Name
                </label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  placeholder="Enter product name"
                  value={product.name}
                  onChange={handleChange}
                  className="w-full p-3 rounded-md bg-black/30 border border-white/20 text-white outline-none"
                />
              </div>

              {/* Model */}
              <div>
                <label
                  htmlFor="model"
                  className="block mb-1 text-sm text-white/80"
                >
                  Model
                </label>
                <input
                  type="text"
                  id="model"
                  name="model"
                  placeholder="Enter model"
                  value={product.model}
                  onChange={handleChange}
                  className="w-full p-3 rounded-md bg-black/30 border border-white/20 text-white outline-none"
                />
              </div>

              {/* Category */}
              <div>
                <label
                  htmlFor="category"
                  className="block mb-1 text-sm text-white/80"
                >
                  Category
                </label>
                <input
                  type="text"
                  id="category"
                  name="category"
                  placeholder="Enter category"
                  value={product.category}
                  onChange={handleChange}
                  className="w-full p-3 rounded-md bg-black/30 border border-white/20 text-white outline-none"
                />
              </div>

              {/* Company */}
              <div>
                <label
                  htmlFor="company"
                  className="block mb-1 text-sm text-white/80"
                >
                  Company
                </label>
                <input
                  type="text"
                  id="company"
                  name="company"
                  placeholder="Enter company name"
                  value={product.company}
                  onChange={handleChange}
                  className="w-full p-3 rounded-md bg-black/30 border border-white/20 text-white outline-none"
                />
              </div>

              {/* Purchase Price */}
              <div>
                <label
                  htmlFor="price"
                  className="block mb-1 text-sm text-white/80"
                >
                  Purchase Price
                </label>
                <input
                  type="text"
                  id="price"
                  name="price"
                  placeholder="Enter purchase price"
                  value={product.price}
                  onChange={handleChange}
                  className="w-full p-3 rounded-md bg-black/30 border border-white/20 text-white outline-none"
                />
              </div>

              {/* Quantity */}
              <div>
                <label
                  htmlFor="quantity"
                  className="block mb-1 text-sm text-white/80"
                >
                  Quantity
                </label>
                <input
                  type="text"
                  id="quantity"
                  name="quantity"
                  placeholder="Enter quantity"
                  value={product.quantity}
                  onChange={handleChange}
                  className="w-full p-3 rounded-md bg-black/30 border border-white/20 text-white outline-none"
                />
              </div>

              {/* Value */}
              <div>
                <label
                  htmlFor="value"
                  className="block mb-1 text-sm text-white/80"
                >
                  Value
                </label>
                <input
                  type="text"
                  id="value"
                  name="value"
                  value={product.value}
                  placeholder="0.0"
                  readOnly
                  className="w-full p-3 rounded-md bg-black/40 border border-white/30 text-white outline-none cursor-not-allowed"
                />
              </div>

              {/* Supplier */}
              <div>
                <label
                  htmlFor="supplier"
                  className="block mb-1 text-sm text-white/80"
                >
                  Supplier
                </label>
                <input
                  type="text"
                  id="supplier"
                  name="supplier"
                  placeholder="Enter supplier name"
                  value={product.supplier}
                  onChange={handleChange}
                  className="w-full p-3 rounded-md bg-black/30 border border-white/20 text-white outline-none"
                />
              </div>

              {/* Supplier Contact */}
              <div className="md:col-span-2">
                <label
                  htmlFor="supplierContact"
                  className="block mb-1 text-sm text-white/80"
                >
                  Supplier Contact
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-white/70 select-none">
                    +
                  </span>
                  <input
                    type="text"
                    id="supplierContact"
                    name="supplierContact"
                    placeholder="923001234567"
                    maxLength={15}
                    value={product.supplierContact}
                    onChange={handleChange}
                    className="w-full pl-6 p-3 rounded-md bg-black/30 border border-white/20 text-white outline-none"
                  />
                </div>
              </div>
            </div>

            {/* Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 mt-6">
              <button
                type="submit"
                className="w-full sm:w-1/2 py-3 rounded-md bg-cyan-800/80 hover:bg-cyan-900 transition cursor-pointer font-semibold flex justify-center items-center gap-3"
              >
                <AddIcon />
                Save
              </button>

              <button
                type="button"
                onClick={handleClear}
                className="w-full sm:w-1/2 py-3 rounded-md bg-red-700/80 hover:bg-red-800 transition cursor-pointer font-semibold flex justify-center items-center gap-3"
              >
                Clear
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}