import React, { useState, useMemo, useEffect } from "react";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { X } from "lucide-react";
import SearchIcon from "@mui/icons-material/Search";
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";
import VisibilityIcon from "@mui/icons-material/Visibility";

// ✅ Robust Date Formatter that handles all date formats
const formatDateTime = (dateInput) => {
  if (!dateInput) return "—";

  try {
    let date;

    // Handle different date formats
    if (dateInput instanceof Date) {
      date = dateInput;
    } else if (typeof dateInput === "string") {
      // Try to parse the date string - handle multiple formats
      if (dateInput.includes("/")) {
        // Handle DD/MM/YYYY format
        const parts = dateInput.split(" ");
        const datePart = parts[0];
        const timePart = parts[1];

        if (datePart.includes("/")) {
          const [day, month, year] = datePart.split("/");
          if (timePart) {
            const [hours, minutes, seconds] = timePart.split(":");
            date = new Date(
              year,
              month - 1,
              day,
              hours || 0,
              minutes || 0,
              seconds || 0
            );
          } else {
            date = new Date(year, month - 1, day);
          }
        }
      } else {
        // Try standard Date parsing
        date = new Date(dateInput);
      }
    } else {
      date = new Date(dateInput);
    }

    // Check if date is valid
    if (isNaN(date.getTime())) {
      return "—";
    }

    const day = String(date.getDate()).padStart(2, "0");
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const year = date.getFullYear();
    const hours = String(date.getHours()).padStart(2, "0");
    const minutes = String(date.getMinutes()).padStart(2, "0");
    const seconds = String(date.getSeconds()).padStart(2, "0");

    return `${day}/${month}/${year} ${hours}:${minutes}:${seconds}`;
  } catch (error) {
    console.error("Date formatting error:", error);
    return "—";
  }
};

// ✅ Short Date for Display (Table) - More robust version
const formatShortDate = (dateString) => {
  if (!dateString) return "—";

  try {
    const fullDate = formatDateTime(dateString);
    if (fullDate === "—") return "—";

    // Extract just the date part (DD/MM/YYYY)
    return fullDate.split(" ")[0];
  } catch (error) {
    return "—";
  }
};

/**
 * Loads purchase history data.
 */
// In the loadPurchaseHistory function, update the sorting to be more robust:
const loadPurchaseHistory = () => {
  try {
    const purchaseHistory =
      JSON.parse(localStorage.getItem("purchaseHistory")) || [];

    // Enhanced sorting by date descending (newest first)
    return purchaseHistory.sort((a, b) => {
      // Try multiple date fields to ensure we get the most relevant timestamp
      const getTimestamp = (item) => {
        const dateFields = [
          "savedOn",
          "updatedOn",
          "updatedAt",
          "createdAt",
          "date",
        ];
        for (let field of dateFields) {
          if (item[field]) {
            const timestamp = new Date(item[field]).getTime();
            if (!isNaN(timestamp)) {
              return timestamp;
            }
          }
        }
        return 0; // Fallback for items without valid dates
      };

      const timestampA = getTimestamp(a);
      const timestampB = getTimestamp(b);

      return timestampB - timestampA; // Descending order (newest first)
    });
  } catch {
    console.error("Error loading purchase history from localStorage.");
    return [];
  }
};

export default function PurchaseHistory() {
  const [purchaseHistory, setPurchaseHistory] = useState(loadPurchaseHistory);
  const [query, setQuery] = useState("");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isViewOpen, setIsViewOpen] = useState(false);
  const [form, setForm] = useState({});
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [originalProduct, setOriginalProduct] = useState(null); // Track original data

  // 🟢 Refresh data automatically if storage updates
  useEffect(() => {
    const handleStorage = () => {
      setPurchaseHistory(loadPurchaseHistory());
    };
    window.addEventListener("storage", handleStorage);

    // Also refresh when component mounts
    setPurchaseHistory(loadPurchaseHistory());

    return () => window.removeEventListener("storage", handleStorage);
  }, []);

  const filtered = useMemo(() => {
    let arr = purchaseHistory.slice();
    if (query.trim()) {
      const q = query.toLowerCase();
      arr = arr.filter((p) =>
        [
          p.productId,
          p.name,
          p.model,
          p.category,
          p.company,
          p.supplier,
          p.supplierContact,
          p.invoiceId,
          p.type,
        ]
          .join(" ")
          .toLowerCase()
          .includes(q)
      );
    }
    return arr;
  }, [purchaseHistory, query]);

  // Check if form has been modified and track changes
  const [formChanges, setFormChanges] = useState({});

  const isFormModified = useMemo(() => {
    if (!originalProduct || !form) return false;

    const fieldsToCompare = [
      "name",
      "model",
      "category",
      "company",
      "price",
      "quantity",
      "supplier",
      "supplierContact",
    ];

    const changes = {};
    let hasChanges = false;

    fieldsToCompare.forEach((field) => {
      const originalValue = String(originalProduct[field] || "").trim();
      const formValue = String(form[field] || "").trim();
      if (originalValue !== formValue) {
        changes[field] = {
          from: originalValue,
          to: formValue,
        };
        hasChanges = true;
      }
    });

    setFormChanges(changes);
    return hasChanges;
  }, [form, originalProduct]);

  const toastConfig = { position: "top-right", theme: "dark", autoClose: 2000 };
  const notifySuccess = (msg) => toast.success(msg, toastConfig);
  const notifyError = (msg) => toast.error(msg, toastConfig);

  const handleOpenEdit = (product) => {
    const contactWithoutPlus = product.supplierContact?.startsWith("+")
      ? product.supplierContact.substring(1)
      : product.supplierContact || "";

    const formData = {
      ...product,
      supplierContact: contactWithoutPlus,
      price: product.price || "",
      quantity: product.quantity || "",
    };

    setForm(formData);
    setOriginalProduct(formData);
    setFormChanges({});
    setIsModalOpen(true);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    let val = value;

    if (name === "price") {
      val = value.replace(/[^\d.]/g, "");
    } else if (name === "quantity") {
      val = value.replace(/\D/g, "");
    } else if (name === "supplierContact") {
      let digits = value.replace(/\D/g, "");
      if (digits.length > 15) digits = digits.slice(0, 15);
      val = digits;
    }

    setForm((s) => ({ ...s, [name]: val }));
  };

  // Function to get field display name
  const getFieldDisplayName = (field) => {
    const fieldNames = {
      name: "Product Name",
      model: "Model",
      category: "Category",
      company: "Company",
      price: "Purchase Price",
      quantity: "Quantity",
      supplier: "Supplier",
      supplierContact: "Supplier Contact",
    };
    return fieldNames[field] || field;
  };

  const handleSave = (e) => {
    e.preventDefault();

    const originalProduct = purchaseHistory.find(
      (p) => p.productId === form.productId && p.invoiceId === form.invoiceId
    );

    const trimmedForm = Object.fromEntries(
      Object.entries(form).map(([k, v]) =>
        typeof v === "string" ? [k, v.trim()] : [k, v]
      )
    );

    // 🧱 Validation
    if (!trimmedForm.name) return notifyError("Name is required");
    if (!trimmedForm.model) return notifyError("Model is required");
    if (!trimmedForm.category) return notifyError("Category is required");
    if (!trimmedForm.company) return notifyError("Company is required");
    if (!trimmedForm.supplier) return notifyError("Supplier is required");

    const price = parseFloat(trimmedForm.price);
    const quantity = parseInt(trimmedForm.quantity);

    if (isNaN(price) || price <= 0)
      return notifyError("Valid Purchase Price is required");
    if (isNaN(quantity) || quantity <= 0)
      return notifyError("Valid Quantity is required");

    const fullSupplierContact = "+" + trimmedForm.supplierContact;
    if (!/^\+\d{7,15}$/.test(fullSupplierContact))
      return notifyError(
        "Supplier Contact must start with '+' followed by 7–15 digits"
      );

    const total = (price * quantity).toFixed(2);

    // Create update message with changed fields
    const changedFields = Object.keys(formChanges);
    const updateMessage =
      changedFields.length > 0
        ? `Updated: ${changedFields
            .map((field) => getFieldDisplayName(field))
            .join(", ")}`
        : "Record updated";

    const updatedProduct = {
      ...trimmedForm,
      price: price.toFixed(2),
      quantity: String(quantity),
      total,
      value: total,
      supplierContact: fullSupplierContact,
      updatedAt: formatDateTime(new Date()),
      lastUpdateMessage: updateMessage,
    };

    // Update purchase history
    const updatedHistory = purchaseHistory.map((p) =>
      p.productId === updatedProduct.productId &&
      p.invoiceId === updatedProduct.invoiceId
        ? updatedProduct
        : p
    );

    setPurchaseHistory(updatedHistory);
    localStorage.setItem("purchaseHistory", JSON.stringify(updatedHistory));

    // Also update products if this is the latest entry for this product
    const products = JSON.parse(localStorage.getItem("products") || "[]");
    const productEntries = purchaseHistory.filter(
      (p) => p.productId === updatedProduct.productId
    );
    const latestEntry = productEntries.sort(
      (a, b) => new Date(b.savedOn) - new Date(a.savedOn)
    )[0];

    if (latestEntry && latestEntry.invoiceId === updatedProduct.invoiceId) {
      const updatedProducts = products.map((p) =>
        p.productId === updatedProduct.productId
          ? { ...p, ...updatedProduct }
          : p
      );
      localStorage.setItem("products", JSON.stringify(updatedProducts));
    }

    setIsModalOpen(false);
    setOriginalProduct(null); // Reset original product
    setFormChanges({});
    notifySuccess(`${updatedProduct.productId} updated successfully.`);
  };

  const handlePrint = () => {
    const bodyOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    window.print();
    document.body.style.overflow = bodyOverflow;
  };

  const getPurchaseType = (product) => {
    return product.type === "stock-addition"
      ? "Stock Addition"
      : "New Purchase";
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setOriginalProduct(null); // Reset original product when closing modal
    setFormChanges({});
  };

  return (
    <div className="p-2 min-h-screen text-white">
      <ToastContainer position="top-right" theme="dark" autoClose={2000} />
      <div className="max-w-7xl mx-auto space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">
            Purchase History
          </h1>
          <p className="text-white/80">
            View all purchase and stock addition records with invoice details.
          </p>
        </div>

        {/* Search Filter */}
        <div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-md p-4 grid grid-cols-1 md:grid-cols-3 gap-3 ">
          <div className="flex items-center gap-2 rounded border border-white/10 bg-white/5 px-3 py-2 md:col-span-2">
            <SearchIcon className="text-white" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search"
              className="flex-1 outline-none bg-transparent text-white placeholder-white/60"
            />
          </div>
          <div className="text-white/80 text-lg flex items-center">
            Total Records: {filtered.length}
          </div>
        </div>

        {/* Purchase History Table */}
        <div className="bg-white/5 backdrop-blur-lg border border-white/10 rounded-md overflow-x-auto scrollbar-hide ">
          <table className="w-full text-white/90 min-w-[1200px]">
            <thead className="bg-white/10 text-left text-sm">
              <tr>
                <th className="p-3">Invoice ID</th>
                <th className="p-3">Product ID</th>
                <th className="p-3">Name</th>
                <th className="p-3">Type</th>
                <th className="p-3">Qty</th>
                <th className="p-3">Price</th>
                <th className="p-3">Total</th>
                <th className="p-3">Supplier</th>
                <th className="p-3">Date</th>
                <th className="p-3">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((p) => (
                <tr
                  key={`${p.invoiceId}-${p.productId}`}
                  className={`border-t border-white/5 transition 
        ${
          p.type === "stock-addition"
            ? "hover:bg-blue-600/50"
            : "hover:bg-green-600/50"
        }`}
                >
                  <td className="p-3 font-mono">{p.invoiceId}</td>
                  <td className="p-3 font-mono">{p.productId}</td>
                  <td className="p-3">{p.name}</td>
                  <td className="p-3">
                    <span
                      className={`px-2 py-1 rounded text-xs border border-white/30 ${
                        p.type === "stock-addition"
                          ? "bg-blue-600"
                          : "bg-green-600"
                      }`}
                    >
                      {getPurchaseType(p)}
                    </span>
                  </td>
                  <td className="p-3">{p.quantity}</td>
                  <td className="p-3">Rs {p.price}/-</td>
                  <td className="p-3">Rs {p.total}/-</td>
                  <td className="p-3">{p.supplier}</td>
                  <td className="p-3 text-sm">{formatShortDate(p.savedOn)}</td>
                  <td className="p-3 flex gap-2">
                    <button
                      title="View"
                      onClick={() => {
                        setSelectedProduct(p);
                        setIsViewOpen(true);
                      }}
                      className="p-2 rounded bg-cyan-900 text-white hover:bg-cyan-950 transition-colors cursor-pointer"
                    >
                      <VisibilityIcon fontSize="small" />
                    </button>
                    <button
                      title="Edit"
                      onClick={() => handleOpenEdit(p)}
                      className="p-2 rounded bg-yellow-400 text-gray-900 hover:bg-yellow-300 transition-colors cursor-pointer"
                    >
                      <EditIcon fontSize="small" />
                    </button>
                  </td>
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr>
                  <td colSpan="10" className="p-4 text-center text-white/70">
                    No purchase records found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* --- Edit Modal --- */}
      {isModalOpen && (
        <div className="fixed inset-0 flex items-center justify-center bg-black/30 z-50 backdrop-blur-md p-2">
          <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-lg p-6 w-full max-w-lg text-white">
            <div className="mb-4">
              <h2 className="text-xl font-semibold">Edit Purchase Record</h2>
              <div className="text-sm text-white/80 mt-2 space-y-1">
                <p>
                  <strong>Invoice ID:</strong> {form.invoiceId}
                </p>
                <p>
                  <strong>Product ID:</strong> {form.productId}
                </p>
                <p>
                  <strong>Type:</strong> {getPurchaseType(form)}
                </p>

                {/* Display changes summary */}
                {isFormModified && (
                  <div className="mt-3 p-2 bg-yellow-500/20 border border-yellow-500/30 rounded">
                    <p className="font-medium text-yellow-300">
                      Changes detected:
                    </p>
                    <ul className="text-xs mt-1 space-y-1">
                      {Object.entries(formChanges).map(([field, change]) => (
                        <li key={field} className="flex justify-between">
                          <span>{getFieldDisplayName(field)}:</span>
                          <span className="text-yellow-200">
                            "{change.from}" → "{change.to}"
                          </span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            </div>

            <form onSubmit={handleSave} className="space-y-3">
              <input
                name="name"
                value={form.name || ""}
                onChange={handleChange}
                placeholder="Name"
                className="w-full p-2 rounded bg-black/30 border border-white/20 outline-none"
              />
              <input
                name="model"
                value={form.model || ""}
                onChange={handleChange}
                placeholder="Model"
                className="w-full p-2 rounded bg-black/30 border border-white/20 outline-none"
              />
              <input
                name="category"
                value={form.category || ""}
                onChange={handleChange}
                placeholder="Category"
                className="w-full p-2 rounded bg-black/30 border border-white/20 outline-none"
              />
              <input
                name="company"
                value={form.company || ""}
                onChange={handleChange}
                placeholder="Company"
                className="w-full p-2 rounded bg-black/30 border border-white/20 outline-none"
              />
              <input
                name="price"
                value={form.price || ""}
                onChange={handleChange}
                placeholder="Purchase Price"
                className="w-full p-2 rounded bg-black/30 border border-white/20 outline-none"
              />
              <input
                name="quantity"
                value={form.quantity || ""}
                onChange={handleChange}
                placeholder="Quantity"
                className="w-full p-2 rounded bg-black/30 border border-white/20 outline-none"
              />
              <input
                name="supplier"
                value={form.supplier || ""}
                onChange={handleChange}
                placeholder="Supplier"
                className="w-full p-2 rounded bg-black/30 border border-white/20 outline-none"
              />
              <div className="relative">
                <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-white/70 select-none">
                  +
                </span>
                <input
                  type="text"
                  name="supplierContact"
                  value={form.supplierContact || ""}
                  onChange={handleChange}
                  placeholder="Supplier Contact (e.g. 923001234567)"
                  className="w-full pl-6 p-2 rounded bg-black/30 border border-white/20 outline-none"
                />
              </div>

              <div className="flex justify-end gap-3 pt-4">
                <button
                  type="submit"
                  disabled={!isFormModified}
                  className={`px-4 py-2 rounded border border-white/40 transition hover:cursor-pointer ${
                    isFormModified
                      ? "bg-cyan-800/80 hover:bg-cyan-900"
                      : "bg-gray-600/50 cursor-not-allowed opacity-50"
                  }`}
                >
                  Save Changes
                </button>
                <button
                  type="button"
                  onClick={handleCloseModal}
                  className="px-4 py-2 rounded border border-white/40 bg-red-600 hover:bg-red-700 transition hover:cursor-pointer"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* --- View Modal --- */}
      {isViewOpen && selectedProduct && (
        <div className="fixed inset-0 flex items-center justify-center bg-black/30 z-50 p-2 md:p-4 backdrop-blur-md print:p-0">
          <div className="bg-white text-black rounded-lg w-full max-w-md mx-auto max-h-[95vh] overflow-y-auto scrollbar-hide relative font-sans text-sm border border-gray-300">
            {/* Content */}
            <div className="p-4 space-y-3">
              {/* Company Header */}
              <div className="text-center border-b border-dashed border-gray-300 pb-3 mb-3">
                <h2 className="text-xl font-bold tracking-wider text-gray-900">
                  ZUBI ELECTRONICS
                </h2>
                <p className="text-sm text-gray-600 mt-1">
                  Purchase & Invoice Details
                </p>
                <div className="mt-2 space-y-1">
                  <p className="text-xs font-semibold text-gray-700">
                    Invoice: {selectedProduct.invoiceId}
                  </p>
                  <span
                    className={`inline-block px-2 py-1 rounded text-xs ${
                      selectedProduct.type === "stock-addition"
                        ? "bg-blue-100 text-blue-800 border border-blue-200"
                        : "bg-green-200 text-green-800 border border-green-200"
                    }`}
                  >
                    {getPurchaseType(selectedProduct)}
                  </span>
                </div>
              </div>

              {/* Product Information */}
              <div className="space-y-3">
                <div className="grid grid-cols-2 gap-2">
                  <span className="font-medium text-gray-700">Product ID:</span>
                  <span className="text-gray-900 text-right font-mono">
                    {selectedProduct.productId}
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <span className="font-medium text-gray-700">Name:</span>
                  <span className="text-gray-900 text-right">
                    {selectedProduct.name}
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <span className="font-medium text-gray-700">Model:</span>
                  <span className="text-gray-900 text-right">
                    {selectedProduct.model}
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <span className="font-medium text-gray-700">Category:</span>
                  <span className="text-gray-900 text-right">
                    {selectedProduct.category}
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <span className="font-medium text-gray-700">Company:</span>
                  <span className="text-gray-900 text-right">
                    {selectedProduct.company}
                  </span>
                </div>
              </div>

              {/* Pricing Section */}
              <div className="border-t border-dashed border-gray-300 pt-3 mt-3 space-y-2">
                <div className="grid grid-cols-2 gap-2">
                  <span className="font-medium text-gray-700">Quantity:</span>
                  <span className="text-gray-900 text-right">
                    {selectedProduct.quantity} piece(s)
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <span className="font-medium text-gray-700">
                    Purchase Price:
                  </span>
                  <span className="text-gray-900 text-right">
                    Rs {selectedProduct.price}/-
                  </span>
                </div>
              </div>

              {/* Total Value */}
              <div className="bg-blue-200 border border-blue-200 rounded-md p-2 mt-3">
                <div className="grid grid-cols-2 gap-2">
                  <span className="font-bold text-blue-900">
                    Purchase Value:
                  </span>
                  <span className="font-bold text-blue-900 text-right">
                    Rs {selectedProduct.total}/-
                  </span>
                </div>
              </div>

              {/* Supplier Information */}
              <div className="border-t border-dashed border-gray-300 pt-3 mt-3 space-y-2">
                <div className="grid grid-cols-2 gap-2">
                  <span className="font-medium text-gray-700">Supplier:</span>
                  <span className="text-gray-900 text-right">
                    {selectedProduct.supplier}
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <span className="font-medium text-gray-700">
                    Supplier Contact:
                  </span>
                  <span className="text-gray-900 text-right">
                    {selectedProduct.supplierContact}
                  </span>
                </div>
              </div>

              {/* Dates */}
              <div className="text-xs text-gray-500 italic border-t border-dashed border-gray-300 pt-3 mt-3">
                <div className="grid grid-cols-2 gap-2">
                  <span>Purchase Date:</span>
                  <span className="text-right">
                    {formatDateTime(selectedProduct.savedOn)}
                  </span>
                </div>
                {selectedProduct.updatedAt && (
                  <div className="grid grid-cols-2 gap-2 mt-1">
                    <span>Last Updated:</span>
                    <span className="text-right">
                      {formatDateTime(selectedProduct.updatedAt)}
                    </span>
                  </div>
                )}
                {selectedProduct.lastUpdateMessage && (
                  <div className="col-span-2 mt-2 p-2 bg-yellow-100 border border-yellow-300 rounded text-yellow-800">
                    <span className="font-medium">Update Note: </span>
                    {selectedProduct.lastUpdateMessage}
                  </div>
                )}
              </div>

              {/* Footer */}
              <div className="text-center border-t border-dashed border-gray-300 pt-4 text-xs text-gray-600">
                <p>This is a computer-generated purchase record.</p>
                <p>Contains invoice and purchase details only.</p>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="sticky bottom-0 bg-white border-t border-gray-200 rounded-b-lg p-2 print:hidden">
              <div className="flex flex-col sm:flex-row gap-2 justify-end">
                <button
                  onClick={handlePrint}
                  className="px-4 py-2 rounded bg-blue-600 cursor-pointer text-white hover:bg-blue-700 transition font-medium flex items-center justify-center gap-2"
                >
                  <span>🖨️</span>
                  <span>Print</span>
                </button>
                <button
                  onClick={() => setIsViewOpen(false)}
                  className="px-4 py-2 rounded bg-gray-600 cursor-pointer text-white hover:bg-gray-700 transition font-medium"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
