import React from 'react'

const SalesReport = () => {
  return (
    <div>SalesReport</div>
  )
}

export default SalesReport