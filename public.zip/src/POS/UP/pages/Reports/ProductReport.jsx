import React from 'react'

const ProductReport = () => {
  return (
    <div>ProductReport</div>
  )
}

export default ProductReport