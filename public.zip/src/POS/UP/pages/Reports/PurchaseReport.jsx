import React from 'react'

const PurchaseReport = () => {
  return (
    <div>PurchaseReport</div>
  )
}

export default PurchaseReport