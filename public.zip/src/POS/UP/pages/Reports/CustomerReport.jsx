import React from 'react'

const CustomerReport = () => {
  return (
    <div>CustomerReport</div>
  )
}

export default CustomerReport