import React, { useState, useEffect } from "react";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { useNavigate } from "react-router-dom";
import AddIcon from "@mui/icons-material/Add";
import ClearIcon from "@mui/icons-material/Clear";

const loadProducts = () => {
  const stored = localStorage.getItem("products");
  return stored ? JSON.parse(stored) : [];
};

// ✅ Improved Invoice ID Generator
const generateInvoiceId = () => {
  const existingProducts = JSON.parse(localStorage.getItem("products") || "[]");
  const existingHistory = JSON.parse(
    localStorage.getItem("purchaseHistory") || "[]"
  );
  const allInvoices = [...existingProducts, ...existingHistory]
    .map((item) => item.invoiceId)
    .filter((id) => id && id.startsWith("Inv-"));

  if (allInvoices.length === 0) return "Inv-001";

  const lastSavedNum = allInvoices.reduce((max, id) => {
    const num = parseInt(id.replace("Inv-", ""), 10);
    return !isNaN(num) && num > max ? num : max;
  }, 0);

  const nextNum = lastSavedNum + 1;
  return `Inv-${String(nextNum).padStart(3, "0")}`;
};

// ✅ Robust Date Formatter that handles all date formats
const formatDateTime = (dateInput) => {
  if (!dateInput) return "—";

  try {
    let date;

    // Handle different date formats
    if (dateInput instanceof Date) {
      date = dateInput;
    } else if (typeof dateInput === "string") {
      // Try to parse the date string - handle multiple formats
      if (dateInput.includes("/")) {
        // Handle DD/MM/YYYY format
        const parts = dateInput.split(" ");
        const datePart = parts[0];
        const timePart = parts[1];

        if (datePart.includes("/")) {
          const [day, month, year] = datePart.split("/");
          if (timePart) {
            const [hours, minutes, seconds] = timePart.split(":");
            date = new Date(
              year,
              month - 1,
              day,
              hours || 0,
              minutes || 0,
              seconds || 0
            );
          } else {
            date = new Date(year, month - 1, day);
          }
        }
      } else {
        // Try standard Date parsing
        date = new Date(dateInput);
      }
    } else {
      date = new Date(dateInput);
    }

    // Check if date is valid
    if (isNaN(date.getTime())) {
      return "—";
    }

    const day = String(date.getDate()).padStart(2, "0");
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const year = date.getFullYear();
    const hours = String(date.getHours()).padStart(2, "0");
    const minutes = String(date.getMinutes()).padStart(2, "0");
    const seconds = String(date.getSeconds()).padStart(2, "0");

    return `${day}/${month}/${year} ${hours}:${minutes}:${seconds}`;
  } catch (error) {
    console.error("Date formatting error:", error);
    return "—";
  }
};

// ✅ Short Date for Display (Table) - More robust version
const formatShortDate = (dateString) => {
  if (!dateString) return "—";

  try {
    const fullDate = formatDateTime(dateString);
    if (fullDate === "—") return "—";

    // Extract just the date part (DD/MM/YYYY)
    return fullDate.split(" ")[0];
  } catch (error) {
    return "—";
  }
};

// 🟢 NEW: Calculate Price per Unit
const calculatePricePerUnit = (
  previousValue,
  currentPurchaseValue,
  previousQuantity,
  additionalQuantity
) => {
  const totalValue =
    parseFloat(previousValue || 0) + parseFloat(currentPurchaseValue || 0);
  const totalQuantity =
    parseInt(previousQuantity || 0) + parseInt(additionalQuantity || 0);

  if (totalQuantity === 0) return "0.00";

  const pricePerUnit = totalValue / totalQuantity;
  return pricePerUnit.toFixed(2);
};

export default function AddStock() {
  const navigate = useNavigate();
  const [products, setProducts] = useState(loadProducts());
  const [selectedId, setSelectedId] = useState("");
  const [product, setProduct] = useState(null);
  const [additionalQty, setAdditionalQty] = useState("");
  const [newInvoiceId, setNewInvoiceId] = useState("");
  const [showConfirmModal, setShowConfirmModal] = useState(false);

  // 🟢 NEW: State for new stock fields (not fetched from localStorage)
  const [newPurchasePrice, setNewPurchasePrice] = useState("");
  const [newSupplier, setNewSupplier] = useState("");
  const [newSupplierContact, setNewSupplierContact] = useState("");

  // 🟢 NEW: State for price per unit
  const [pricePerUnit, setPricePerUnit] = useState("0.00");

  // 🟢 Generate new invoice ID when component mounts
  useEffect(() => {
    setNewInvoiceId(generateInvoiceId());
  }, []);

  // 🟢 When selecting a product, only fetch basic product info, reset new stock fields
  useEffect(() => {
    if (!selectedId) return;
    const found = products.find((p) => p.productId === selectedId);
    if (found) {
      // Only set basic product info from localStorage
      setProduct({
        productId: found.productId,
        name: found.name,
        model: found.model,
        category: found.category,
        quantity: found.quantity,
        company: found.company,
        value: found.value || "0.00", 
      });

      // Reset new stock fields
      setNewPurchasePrice("");
      setAdditionalQty("");
      setNewSupplier("");
      setNewSupplierContact("");
      setPricePerUnit("0.00");
    } else {
      setProduct(null);
      toast.error("Product not found!", { theme: "dark", autoClose: 2000 });
    }
  }, [selectedId, products]);

  // 💰 FIXED: Calculate totals correctly using new values
  useEffect(() => {
    if (!product) return;

    const price = parseFloat(newPurchasePrice) || 0;
    const currentQty = parseInt(product.quantity) || 0;
    const addQty = parseInt(additionalQty) || 0;
    const newTotalQty = currentQty + addQty;

    // FIX 1: Purchase value is only for additional quantity
    const purchaseValue = (price * addQty).toFixed(2);

    // FIX 2: Total inventory value = previous value + current purchase value
    const previousValue = parseFloat(product.value) || 0;
    const totalInventoryValue = (
      previousValue + parseFloat(purchaseValue)
    ).toFixed(2);

    // 🟢 NEW: Calculate price per unit
    const calculatedPricePerUnit = calculatePricePerUnit(
      product.value,
      purchaseValue,
      product.quantity,
      additionalQty
    );
    setPricePerUnit(calculatedPricePerUnit);

    // Update product with calculated values
    setProduct((prev) => ({
      ...prev,
      purchaseValue, // Value for additional quantity only
      totalInventoryValue, // Previous + current purchase value
      additionTotal: purchaseValue,
      pricePerUnit: calculatedPricePerUnit,
    }));
  }, [newPurchasePrice, additionalQty, product?.quantity, product?.value]);

  const handleChange = (e) => {
    const { name, value } = e.target;

    if (name === "newPurchasePrice") {
      const val = value.replace(/[^\d.]/g, "");
      setNewPurchasePrice(val);
      return;
    }

    if (name === "additionalQty") {
      const val = value.replace(/\D/g, "");
      setAdditionalQty(val);
      return;
    }

    if (name === "newSupplierContact") {
      let digits = value.replace(/\D/g, "");
      if (digits.length > 15) digits = digits.slice(0, 15);
      setNewSupplierContact(digits);
      return;
    }

    if (name === "newSupplier") {
      setNewSupplier(value);
      return;
    }
  };

  const handleClear = () => {
    setSelectedId("");
    setProduct(null);
    setNewPurchasePrice("");
    setAdditionalQty("");
    setNewSupplier("");
    setNewSupplierContact("");
    setPricePerUnit("0.00");
    toast.info("Form cleared", { theme: "dark", autoClose: 1500 });
  };

  const handleSave = (e) => {
    e.preventDefault();
    if (!product) return toast.error("No product selected!", { theme: "dark" });

    const toastOptions = { theme: "dark", autoClose: 2000 };

    if (
      !newPurchasePrice ||
      isNaN(newPurchasePrice) ||
      parseFloat(newPurchasePrice) <= 0
    )
      return toast.error("Valid Purchase Price is required", toastOptions);
    if (!additionalQty || isNaN(additionalQty) || parseInt(additionalQty) <= 0)
      return toast.error("Valid Additional Quantity is required", toastOptions);
    if (!newSupplier.trim())
      return toast.error("Supplier is required", toastOptions);

    // 🟢 Add "+" before saving supplier contact
    const fullSupplierContact = "+" + newSupplierContact;
    if (!/^\+\d{7,15}$/.test(fullSupplierContact))
      return toast.error(
        "Supplier Contact must start with '+' followed by 7–15 digits",
        toastOptions
      );

    // Show confirmation modal instead of directly saving
    setShowConfirmModal(true);
  };

  const confirmSave = () => {
    if (!product) return;

    // Calculate new total quantity
    const currentQty = parseInt(product.quantity) || 0;
    const addQty = parseInt(additionalQty) || 0;
    const newTotalQty = currentQty + addQty;

    // Calculate values correctly
    const purchasePrice = parseFloat(newPurchasePrice);
    const purchaseValue = purchasePrice * addQty; // Only for additional quantity

    // Previous inventory value from localStorage
    const previousValue = parseFloat(product.value) || 0;
    const totalInventoryValue = previousValue + purchaseValue;

    // 🟢 Calculate final price per unit for storage
    const finalPricePerUnit = calculatePricePerUnit(
      product.value,
      purchaseValue,
      product.quantity,
      additionalQty
    );

    // --- Update product list ---
    const updatedProducts = products.map((p) =>
      p.productId === product.productId
        ? {
            ...p,
            price: newPurchasePrice, // Use new purchase price
            quantity: newTotalQty.toString(),
            supplier: newSupplier, // Use new supplier
            supplierContact: "+" + newSupplierContact, // Use new supplier contact
            value: totalInventoryValue.toFixed(2), // Total inventory value
            pricePerUnit: finalPricePerUnit, // 🟢 Store price per unit
            updatedOn: formatDateTime(new Date()),
          }
        : p
    );

    localStorage.setItem("products", JSON.stringify(updatedProducts));
    setProducts(updatedProducts);

    // --- UPDATE Purchase History ---
    const existingHistory =
      JSON.parse(localStorage.getItem("purchaseHistory")) || [];

    const newPurchaseEntry = {
      ...product,
      productId: product.productId,
      invoiceId: newInvoiceId,
      quantity: additionalQty, // Only additional quantity
      price: newPurchasePrice, // Use new purchase price
      supplierContact: "+" + newSupplierContact, // Use new supplier contact
      total: purchaseValue.toFixed(2), // Value for additional quantity only
      value: purchaseValue.toFixed(2),
      pricePerUnit: finalPricePerUnit, // 🟢 Include price per unit in history
      savedOn: formatDateTime(new Date()),
      name: product.name,
      model: product.model,
      category: product.category,
      supplier: newSupplier, // Use new supplier
      type: "stock-addition",
    };

    const updatedHistory = [...existingHistory, newPurchaseEntry];
    localStorage.setItem("purchaseHistory", JSON.stringify(updatedHistory));

    setShowConfirmModal(false);
    toast.success(`Stock added with Invoice ${newInvoiceId}`, {
      theme: "dark",
      autoClose: 2000,
      onClose: () => navigate("/up-purchase-history"),
    });
  };

  const cancelSave = () => {
    setShowConfirmModal(false);
  };

  // Calculate values for display
  const getPurchaseValue = () => {
    if (!product) return "0.00";
    const price = parseFloat(newPurchasePrice) || 0;
    const addQty = parseInt(additionalQty) || 0;
    return (price * addQty).toFixed(2);
  };

  const getTotalInventoryValue = () => {
    if (!product) return "0.00";
    const previousValue = parseFloat(product.value) || 0;
    const purchaseValue = parseFloat(getPurchaseValue()) || 0;
    return (previousValue + purchaseValue).toFixed(2);
  };

  const getPreviousInventoryValue = () => {
    if (!product) return "0.00";
    return parseFloat(product.value || "0").toFixed(2);
  };

  return (
    <div className="px-4 py-2 min-h-screen ">
      <ToastContainer theme="dark" autoClose={2000} />
      <div className="max-w-8xl mx-auto">
        {/* Header */}
        <div className="mb-4 ">
          <h1 className="text-3xl font-bold text-white">Add Stock</h1>
          <p className="text-white">
            Select a Product ID to update stock and pricing details.
          </p>
        </div>

        {/* Main Glassy Card */}
        <div className="bg-white/5 backdrop-blur-xl border border-white/20 rounded-2xl shadow-2xl overflow-hidden">
          {/* Card Content with Scroll */}
          <div className="p-4 md:p-6 h-full overflow-y-auto">
            {/* Product Selector */}
            <div className="mb-6">
              <label
                htmlFor="productId"
                className="block mb-2 text-sm font-medium text-white"
              >
                Select Product ID
              </label>
              <select
                id="productId"
                value={selectedId}
                onChange={(e) => setSelectedId(e.target.value)}
                className="w-full p-3 rounded-lg bg-black/30 border border-white/20 text-white outline-none focus:ring-2 focus:ring-white/30 focus:border-transparent transition-all"
              >
                <option value="" className="bg-black/90">
                  -- Select Product --
                </option>
                {products.map((p) => (
                  <option
                    className="bg-black/90"
                    key={p.productId}
                    value={p.productId}
                  >
                    {p.name}
                  </option>
                ))}
              </select>
            </div>

            {!product ? (
              <div className="text-center py-12 md:py-16 border-2 border-dashed border-white/20  rounded-md bg-white/5">
                <div className="text-white text-4xl md:text-6xl mb-4">📦</div>
                <p className="text-white italic text-base md:text-lg">
                  Select a Product ID to view details
                </p>
                <p className="text-white text-xs md:text-sm mt-2">
                  Choose from the dropdown above to begin adding stock
                </p>
              </div>
            ) : (
              <form onSubmit={handleSave} className="space-y-4 md:space-y-6">
                {/* Product Information Section */}
                <div className="bg-cyan-800/70 backdrop-blur-md border border-cyan-800 rounded-md p-4 md:p-6 shadow-lg">
                  <h3 className="text-lg md:text-xl font-bold text-white mb-4 flex items-center gap-2">
                    <span className="text-white">📋</span>
                    Product Information
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 md:gap-4">
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-white text-sm">Invoice No:</span>
                        <span className="font-mono font-bold text-white text-sm md:text-base">
                          {newInvoiceId}
                        </span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-white text-sm">Product ID:</span>
                        <span className="font-mono font-semibold text-white text-sm md:text-base">
                          {product.productId}
                        </span>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-white text-sm">Name:</span>
                        <span className="font-semibold text-white text-sm md:text-base">
                          {product.name}
                        </span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-white text-sm">Model:</span>
                        <span className="font-semibold text-white text-sm md:text-base">
                          {product.model}
                        </span>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-white text-sm">Category:</span>
                        <span className="font-semibold text-white text-sm md:text-base">
                          {product.category}
                        </span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-white text-sm">Company:</span>
                        <span className="font-semibold text-white text-sm md:text-base">
                          {product.company}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Pricing & Stock Management Section */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-6">
                  {/* 🟩 Supplier Information */}
                  <div className="bg-cyan-800/70 backdrop-blur-md border border-cyan-800 rounded-md p-4 md:p-6">
                    <h4 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                      <span className="text-cyan-900">💰</span>
                      Supplier Information (New Stock)
                    </h4>

                    <div className="grid grid-cols-1 gap-4">
                      {/* Supplier Name */}
                      <div>
                        <label className="block mb-2 text-sm font-medium text-white">
                          Supplier Name
                        </label>
                        <input
                          type="text"
                          name="newSupplier"
                          value={newSupplier}
                          onChange={handleChange}
                          className="w-full p-3 rounded-lg bg-black/30 border border-white/20 text-white outline-none focus:ring-2 focus:ring-white/30 focus:border-transparent transition-all"
                          placeholder="Enter supplier name"
                        />
                      </div>

                      {/* Supplier Contact */}
                      <div>
                        <label className="block mb-2 text-sm font-medium text-white">
                          Supplier Contact
                        </label>
                        <div className="relative">
                          <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-white select-none text-lg">
                            +
                          </span>
                          <input
                            type="text"
                            name="newSupplierContact"
                            value={newSupplierContact}
                            onChange={handleChange}
                            className="w-full pl-10 p-3 rounded-lg bg-black/30 border border-white/20 text-white outline-none focus:ring-2 focus:ring-white/30 focus:border-transparent transition-all"
                            placeholder="923001234567"
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* 🟦 Stock Management Section (unchanged) */}
                  <div className="bg-cyan-800/70 backdrop-blur-md border border-cyan-800   rounded-md p-4 md:p-6">
                    <h4 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                      <span className="text-yellow-300">📊</span>
                      Stock Management
                    </h4>

                    <div className="space-y-2">
                      <div className="text-center p-2 bg-black/20 rounded-lg border border-cyan-900">
                        <label className="block mb-2 text-sm font-medium text-white">
                          Current Stock
                        </label>
                        <div className="text-2xl md:text-2xl font-bold text-yellow-300">
                          {product.quantity} pcs
                        </div>
                      </div>

                      <div>
                        <label className="block mb-2 text-sm font-medium text-white">
                          Additional Quantity
                        </label>
                        <input
                          type="text"
                          name="additionalQty"
                          value={additionalQty}
                          onChange={handleChange}
                          placeholder="Enter quantity to add"
                          className="w-full p-3 rounded-lg bg-black/30 border border-white/20 text-white outline-none focus:ring-2 focus:ring-white/30 focus:border-transparent transition-all"
                        />
                      </div>

                      <div className="text-center p-3 bg-black/20 rounded-lg border border-cyan-900">
                        <label className="block mb-1 text-sm font-medium text-white">
                          New Total Stock
                        </label>
                        <div className="text-lg font-bold text-yellow-300">
                          {parseInt(product.quantity) +
                            parseInt(additionalQty || 0)}{" "}
                          pcs
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Pricing Details */}
                <div className="bg-cyan-800/70 backdrop-blur-md border border-cyan-800   rounded-md p-4 md:p-6">
                  <h4 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                    <span className="text-blue-300">🏢</span>
                    Pricing Details (New Stock)
                  </h4>

                  <div className="space-y-4">
                    <div>
                      <label className="block mb-2 text-sm font-medium text-white">
                        Purchase Price (for new stock)
                      </label>
                      <input
                        type="text"
                        name="newPurchasePrice"
                        value={newPurchasePrice}
                        onChange={handleChange}
                        className="w-full p-3 rounded-lg bg-black/30 border border-white/20 text-white outline-none focus:ring-2 focus:ring-white/30 focus:border-transparent transition-all"
                        placeholder="0.00"
                      />
                      <p className="text-xs text-white mt-1">
                        Applies only to additional quantity
                      </p>
                    </div>
                  </div>
                </div>

                {/* Financial Summary Section */}
                <div className="bg-cyan-800/70 backdrop-blur-md border border-cyan-800   rounded-md p-4 md:p-6">
                  <h4 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                    <span className="text-cyan-300">📈</span>
                    Financial Summary
                  </h4>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-3">
                      <div className="flex justify-between items-center p-3 bg-cyan-800/90 backdrop-blur-md border border-cyan-900 rounded-md">
                        <span className="text-white">
                          Current Purchase Value:
                        </span>
                        <span className="font-bold text-white">
                          Rs {getPurchaseValue()}/-
                        </span>
                      </div>
                      <div className="flex justify-between items-center p-3 bg-cyan-800/90 backdrop-blur-md border border-cyan-900 rounded-md">
                        <span className="text-white">
                          Per Unit Cost (New Stock):
                        </span>
                        <span className="font-semibold text-white">
                          Rs {parseFloat(newPurchasePrice) || "0.00"}/-
                        </span>
                      </div>
                      {/* 🟢 NEW: Price per Unit Display */}
                      <div className="flex justify-between items-center p-3  bg-cyan-800/90 backdrop-blur-md border border-cyan-900 rounded-md">
                        <span className="text-white">
                          Average Price Per Unit:
                        </span>
                        <span className="font-bold text-white">
                          Rs {pricePerUnit}/-
                        </span>
                      </div>
                      <div className="flex justify-between items-center p-3 bg-cyan-800/90 backdrop-blur-md border border-cyan-900 rounded-md">
                        <span className="text-white">
                          Previous Inventory Value:
                        </span>
                        <span className="font-semibold text-white">
                          Rs {getPreviousInventoryValue()}/-
                        </span>
                      </div>
                    </div>
                    <div className="flex flex-col justify-center p-4  bg-cyan-800/90 backdrop-blur-md border border-cyan-900 rounded-md">
                      <span className="text-white text-sm md:text-base mb-2">
                        Total Inventory Value:
                      </span>
                      <span className="text-xl md:text-2xl font-bold text-white">
                        Rs {getTotalInventoryValue()}/-
                      </span>
                    </div>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <button
                    type="submit"
                    className="w-full py-3 md:py-4  rounded-md bg-cyan-950/80 hover:bg-cyan-950  border border-white/30 transition-all duration-300 cursor-pointer font-bold text-base md:text-lg flex justify-center items-center gap-3 shadow-lg hover:shadow-purple-500/25"
                  >
                    <AddIcon />
                    Save
                  </button>
                  <button
                    type="button"
                    onClick={handleClear}
                    className="w-full py-3 md:py-4  rounded-md bg-red-700/80 hover:bg-red-800 border border-white/30  transition-all duration-300 cursor-pointer font-bold text-base md:text-lg flex justify-center items-center gap-3 shadow-lg hover:shadow-red-500/25"
                  >
                    <ClearIcon />
                    Clear
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>

        {/* Confirmation Modal */}
        {showConfirmModal && (
          <div className="fixed inset-0 flex items-center justify-center bg-black/30 backdrop-blur-md z-50 p-4">
            <div className="bg-cyan-800/90 backdrop-blur-md border border-cyan-900 rounded-md p-6 w-full max-w-md text-white ">
              <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
                <span className="text-purple-300">⚠️</span>
                Confirm Stock Update
              </h3>

              <div className="space-y-3 mb-6">
                <div className="flex justify-between">
                  <span className="text-white">Product:</span>
                  <span className="font-semibold">{product.name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-white">Invoice ID:</span>
                  <span className="font-mono font-bold text-white">
                    {newInvoiceId}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-white">Additional Quantity:</span>
                  <span className="font-semibold text-white">
                    {additionalQty} pcs
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-white">New Total Stock:</span>
                  <span className="font-semibold text-white">
                    {parseInt(product.quantity) + parseInt(additionalQty || 0)}{" "}
                    pcs
                  </span>
                </div>
                {/* 🟢 NEW: Price per Unit in confirmation modal */}
                <div className="flex justify-between">
                  <span className="text-white">Average Price Per Unit:</span>
                  <span className="font-bold text-white">
                    Rs {pricePerUnit}/-
                  </span>
                </div>
                <div className="flex justify-between border-t border-white/20 pt-2">
                  <span className="text-white">Purchase Value:</span>
                  <span className="font-bold text-white">
                    Rs {getPurchaseValue()}/-
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-white">Total Inventory Value:</span>
                  <span className="font-bold text-white">
                    Rs {getTotalInventoryValue()}/-
                  </span>
                </div>
              </div>

              <p className="text-white text-sm mb-6">
                Are you sure you want to update the stock and create this
                purchase record?
              </p>

              <div className="flex gap-3">
                <button
                  onClick={cancelSave}
                  className="flex-1 py-3 border border-white/30  rounded-md bg-red-700 hover:bg-red-800 transition-all duration-300 cursor-pointer font-semibold"
                >
                  Cancel
                </button>
                <button
                  onClick={confirmSave}
                  className="flex-1 py-3 border border-white/30  rounded-md bg-cyan-950/70 hover:bg-cyan-950  transition-all duration-300 cursor-pointer font-semibold flex justify-center items-center gap-2"
                >
                  <AddIcon />
                  Confirm
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
