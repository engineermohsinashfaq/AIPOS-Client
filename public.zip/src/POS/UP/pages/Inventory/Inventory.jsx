import React, { useState, useMemo, useEffect } from "react";
import { X } from "lucide-react";
import SearchIcon from "@mui/icons-material/Search";
import VisibilityIcon from "@mui/icons-material/Visibility";
import WarningIcon from "@mui/icons-material/Warning";
import ErrorIcon from "@mui/icons-material/Error";

// ✅ Robust Date Formatter that handles all date formats
const formatDateTime = (dateInput) => {
  if (!dateInput) return "—";

  try {
    let date;

    // Handle different date formats
    if (dateInput instanceof Date) {
      date = dateInput;
    } else if (typeof dateInput === "string") {
      // Try to parse the date string - handle multiple formats
      if (dateInput.includes("/")) {
        // Handle DD/MM/YYYY format
        const parts = dateInput.split(" ");
        const datePart = parts[0];
        const timePart = parts[1];

        if (datePart.includes("/")) {
          const [day, month, year] = datePart.split("/");
          if (timePart) {
            const [hours, minutes, seconds] = timePart.split(":");
            date = new Date(
              year,
              month - 1,
              day,
              hours || 0,
              minutes || 0,
              seconds || 0
            );
          } else {
            date = new Date(year, month - 1, day);
          }
        }
      } else {
        // Try standard Date parsing
        date = new Date(dateInput);
      }
    } else {
      date = new Date(dateInput);
    }

    // Check if date is valid
    if (isNaN(date.getTime())) {
      return "—";
    }

    const day = String(date.getDate()).padStart(2, "0");
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const year = date.getFullYear();
    const hours = String(date.getHours()).padStart(2, "0");
    const minutes = String(date.getMinutes()).padStart(2, "0");
    const seconds = String(date.getSeconds()).padStart(2, "0");

    return `${day}/${month}/${year} ${hours}:${minutes}:${seconds}`;
  } catch (error) {
    console.error("Date formatting error:", error);
    return "—";
  }
};

// ✅ Short Date for Display (Table) - More robust version
const formatShortDate = (dateString) => {
  if (!dateString) return "—";

  try {
    const fullDate = formatDateTime(dateString);
    if (fullDate === "—") return "—";

    // Extract just the date part (DD/MM/YYYY)
    return fullDate.split(" ")[0];
  } catch (error) {
    return "—";
  }
};

const loadProducts = () => {
  try {
    const raw = localStorage.getItem("products");
    const products = raw ? JSON.parse(raw) : [];

    // Ensure all products have createdAt and updatedAt fields
    return products.map((product) => {
      // If product doesn't have createdAt, set it to savedOn or current date
      if (!product.createdAt) {
        product.createdAt = product.savedOn || new Date().toISOString();
      }
      // If product doesn't have updatedAt, set it to updatedOn or savedOn or current date
      if (!product.updatedAt) {
        product.updatedAt =
          product.updatedOn || product.savedOn || new Date().toISOString();
      }
      return product;
    });
  } catch {
    console.error("Error loading products from localStorage.");
    return [];
  }
};

// ✅ FIXED: Use stored value field OR calculate from quantity × price as fallback
const getProductValue = (product) => {
  // First priority: Use the stored value field (which contains accumulated inventory value)
  if (product.value !== undefined && product.value !== null) {
    const storedValue = parseFloat(product.value);
    if (!isNaN(storedValue) && storedValue >= 0) {
      return storedValue.toFixed(2);
    }
  }

  // Fallback: Calculate from quantity × price (for backward compatibility)
  const quantity = parseInt(product.quantity || 0);
  const price = parseFloat(product.price || 0);
  return (quantity * price).toFixed(2);
};

// 🟢 NEW: Calculate Price per Unit
const getPricePerUnit = (product) => {
  // First priority: Use the stored pricePerUnit field
  if (product.pricePerUnit !== undefined && product.pricePerUnit !== null) {
    const storedPricePerUnit = parseFloat(product.pricePerUnit);
    if (!isNaN(storedPricePerUnit) && storedPricePerUnit >= 0) {
      return storedPricePerUnit.toFixed(2);
    }
  }

  // Fallback: Calculate from total value ÷ quantity
  const totalValue = parseFloat(getProductValue(product));
  const quantity = parseInt(product.quantity || 0);

  if (quantity === 0) return "0.00";

  const calculatedPricePerUnit = totalValue / quantity;
  return calculatedPricePerUnit.toFixed(2);
};

// 🟢 NEW: Get Stock Level Status
const getStockLevel = (quantity) => {
  const qty = parseInt(quantity || 0);

  if (qty === 0) {
    return {
      level: "out-of-stock",
      label: "Out of Stock",
      color: "text-white",
      bgColor: "bg-red-500/80",
      borderColor: "border-white/20",
      icon: <ErrorIcon fontSize="small" />,
    };
  } else if (qty <= 5) {
    return {
      level: "low",
      label: "Low Stock",
      color: "text-white",
      bgColor: "bg-orange-500/80",
      borderColor: "border-white/20",
      icon: <WarningIcon fontSize="small" />,
    };
  } else if (qty <= 15) {
    return {
      level: "medium",
      label: "Medium Stock",
      color: "text-white",
      bgColor: "bg-yellow-500/80",
      borderColor: "border-white/20",
      icon: <WarningIcon fontSize="small" />,
    };
  } else {
    return {
      level: "high",
      label: "In Stock",
      color: "text-white",
      bgColor: "bg-green-500",
      borderColor: "border-white/20",
      icon: <span>✓</span>,
    };
  }
};

export default function Inventory() {
  const [products] = useState(loadProducts);
  const [query, setQuery] = useState("");
  const [isViewOpen, setIsViewOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null);

  useEffect(() => {
    if (isViewOpen) {
      document.body.style.overflow = "hidden";
      document.documentElement.style.overflow = "hidden"; // Add this line
    } else {
      document.body.style.overflow = "unset";
      document.documentElement.style.overflow = "unset"; // Add this line
    }

    return () => {
      document.body.style.overflow = "unset";
      document.documentElement.style.overflow = "unset"; // Add this line
    };
  }, [isViewOpen]);

  const filtered = useMemo(() => {
    let arr = products.slice();
    if (query.trim()) {
      const q = query.toLowerCase();
      arr = arr.filter((p) =>
        [
          p.productId,
          p.name,
          p.model,
          p.category,
          p.company,
          p.createdAt,
          p.updatedAt,
        ]
          .join(" ")
          .toLowerCase()
          .includes(q)
      );
    }
    arr.sort((a, b) => a.productId.localeCompare(b.productId));
    return arr;
  }, [products, query]);

  // ✅ FIXED: Calculate total value using stored value field OR calculated value
  const totalValue = useMemo(() => {
    return filtered
      .reduce((sum, p) => {
        const productValue = getProductValue(p);
        return sum + parseFloat(productValue);
      }, 0)
      .toFixed(2);
  }, [filtered]);

  // Calculate total quantity of all filtered products
  const totalQuantity = useMemo(() => {
    return filtered.reduce((sum, p) => sum + parseInt(p.quantity || 0), 0);
  }, [filtered]);

  // 🟢 NEW: Calculate low stock count
  const lowStockCount = useMemo(() => {
    return filtered.filter((p) => parseInt(p.quantity || 0) <= 5).length;
  }, [filtered]);

  // 🟢 NEW: Calculate out of stock count
  const outOfStockCount = useMemo(() => {
    return filtered.filter((p) => parseInt(p.quantity || 0) === 0).length;
  }, [filtered]);

  // ✅ FIXED: Get products with correct values for display
  const productsWithCalculatedValues = useMemo(() => {
    return filtered.map((product) => ({
      ...product,
      displayValue: getProductValue(product), // Use the fixed value calculation
      displayPricePerUnit: getPricePerUnit(product), // 🟢 Add price per unit for display
      stockLevel: getStockLevel(product.quantity), // 🟢 Add stock level info
    }));
  }, [filtered]);

  const handlePrint = () => {
    const bodyOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    window.print();
    document.body.style.overflow = bodyOverflow;
  };

  const handleCloseViewModal = () => {
    setIsViewOpen(false);
  };

  return (
    <div className="p-2 min-h-screen text-white">
      <div className="max-w-8xl mx-auto space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">
            Inventory & Stocks
          </h1>
          <p className="text-white/80">
            View all stocks and inventory records with accumulated values.
          </p>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="bg-blue-600/80 backdrop-blur-md border border-blue-400/80 rounded-lg p-4">
            <h3 className="text-blue-300 text-sm font-semibold">
              Total Products
            </h3>
            <p className="text-2xl font-bold text-white">{filtered.length}</p>
          </div>
          <div className="bg-green-600/80 backdrop-blur-md border border-green-400/80 rounded-lg p-4">
            <h3 className="text-green-300 text-sm font-semibold">
              Total Quantity
            </h3>
            <p className="text-2xl font-bold text-white">
              {totalQuantity} units
            </p>
          </div>
          <div className="bg-purple-600/80 backdrop-blur-md border border-purple-400/80 rounded-lg p-4">
            <h3 className="text-purple-300 text-sm font-semibold">
              Total Inventory Value
            </h3>
            <p className="text-2xl font-bold text-white">Rs {totalValue}/-</p>
          </div>
          {/* 🟢 NEW: Low Stock Alert Card */}
          <div
            className={`bg-red-600/80 backdrop-blur-md border border-red-400/80 rounded-lg p-4 ${
              lowStockCount > 0 || outOfStockCount > 0 ? "animate-pulse" : ""
            }`}
          >
            <h3 className="text-red-200 text-sm font-semibold flex items-center gap-2">
              <WarningIcon fontSize="small" />
              Stock Alerts
            </h3>
            <div className="space-y-1 mt-2">
              {outOfStockCount > 0 && (
                <p className="text-white font-bold flex items-center gap-1">
                  <ErrorIcon fontSize="small" />
                  {outOfStockCount} Out of Stock
                </p>
              )}
              {lowStockCount > 0 && (
                <p className="text-white font-bold flex items-center gap-1">
                  <WarningIcon fontSize="small" />
                  {lowStockCount} Low Stock
                </p>
              )}
              {outOfStockCount === 0 && lowStockCount === 0 && (
                <p className="text-white font-bold">All Good ✓</p>
              )}
            </div>
          </div>
        </div>

        <div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-md p-4 grid grid-cols-1 md:grid-cols-3 gap-3">
          <div className="flex items-center gap-2 rounded border border-white/10 bg-white/5 px-3 py-2 md:col-span-2">
            <SearchIcon className="text-white" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search products..."
              className="flex-1 outline-none bg-transparent text-white placeholder-white/60"
            />
          </div>
        </div>

        <div className="bg-white/5 backdrop-blur-lg border border-white/10 rounded-md overflow-x-auto scrollbar-hide ">
          <table className="w-full text-white min-w-[1200px]  ">
            <thead className="bg-white/10 text-left text-sm">
              <tr className="text-white/90">
                <th className="p-3">P-ID</th>
                <th className="p-3">Name</th>
                <th className="p-3">Category</th>
                <th className="p-3">Qty</th>
                <th className="p-3">Stock Level</th> {/* 🟢 NEW COLUMN */}
                <th className="p-3">Purchase Price</th>
                <th className="p-3">Value</th>
                <th className="p-3">Last Updated</th>
                <th className="p-3">Actions</th>
              </tr>
            </thead>
            <tbody>
              {productsWithCalculatedValues.map((p) => (
                <tr
                  key={p.productId}
                  className={` border-t border-white/15 transition hover:bg-green-500/50 ${
                    p.stockLevel.level === "out-of-stock"
                      ? " hover:bg-red-500/50"
                      : p.stockLevel.level === "low"
                      ? " hover:bg-orange-500/50"
                      : p.stockLevel.level === "medium"
                      ? " hover:bg-yellow-500/50"
                      : ""
                  }`}
                >
                  <td className="p-3 font-mono">{p.productId}</td>
                  <td className="p-3">{p.name}</td>
                  <td className="p-3">{p.category}</td>
                  <td className="p-3 font-semibold">{p.quantity}</td>
                  {/* 🟢 NEW: Stock Level Column */}
                  <td className="p-3">
                    <div
                      className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium border ${p.stockLevel.bgColor} ${p.stockLevel.borderColor} ${p.stockLevel.color}`}
                    >
                      {p.stockLevel.icon}
                      {p.stockLevel.label}
                    </div>
                  </td>
                  <td className="p-3">Rs {p.price}/-</td>
                  <td className="p-3">Rs {p.displayValue}/-</td>
                  <td className="p-3 text-xs">
                    {formatShortDate(p.updatedAt)}
                  </td>
                  <td className="p-3 flex gap-2">
                    <button
                      title="View"
                      onClick={() => {
                        setSelectedProduct({
                          ...p,
                          value: p.displayValue, // Use display value in modal
                          pricePerUnit: p.displayPricePerUnit, // 🟢 Add price per unit to modal
                          stockLevel: p.stockLevel, // 🟢 Add stock level to modal
                        });
                        setIsViewOpen(true);
                      }}
                      className="p-2 rounded bg-cyan-900 text-white hover:bg-cyan-950 transition-colors cursor-pointer"
                    >
                      <VisibilityIcon fontSize="small" />
                    </button>
                  </td>
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr>
                  <td colSpan="12" className="p-4 text-center text-white/70">
                    {" "}
                    {/* 🟢 Updated colSpan */}
                    No products found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* --- View Modal --- */}
      {isViewOpen && selectedProduct && (
        <div className="fixed inset-0 flex items-center justify-center bg-black/50 z-50 p-2 md:p-4 backdrop-blur-md print:p-0">
          <div className="bg-white text-black rounded-lg shadow-2xl w-full max-w-md mx-auto max-h-[95vh] overflow-y-auto scrollbar-hide relative font-sans text-sm border border-gray-300">
            {/* Content */}
            <div className="p-4 space-y-4">
              {/* Company Header */}
              <div className="text-center border-b border-dashed border-gray-300 pb-3 mb-3">
                <h2 className="text-xl font-bold tracking-wider text-gray-900">
                  ZUBI ELECTRONICS
                </h2>
                <p className="text-sm text-gray-600 mt-1">
                  Product & Stock Details
                </p>
              </div>

              {/* Product Information */}
              <div className="space-y-3">
                <div className="grid grid-cols-2 gap-2">
                  <span className="font-medium text-gray-700">ID:</span>
                  <span className="text-gray-900 text-right">
                    {selectedProduct.productId}
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <span className="font-medium text-gray-700">Name:</span>
                  <span className="text-gray-900 text-right">
                    {selectedProduct.name}
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <span className="font-medium text-gray-700">Model:</span>
                  <span className="text-gray-900 text-right">
                    {selectedProduct.model}
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <span className="font-medium text-gray-700">Category:</span>
                  <span className="text-gray-900 text-right">
                    {selectedProduct.category}
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <span className="font-medium text-gray-700">Company:</span>
                  <span className="text-gray-900 text-right">
                    {selectedProduct.company}
                  </span>
                </div>
              </div>

              {/* Pricing Section */}
              <div className="border-t border-dashed border-gray-300 pt-3 mt-3 space-y-2">
                <div className="grid grid-cols-2 gap-2">
                  <span className="font-medium text-gray-700">Quantity:</span>
                  <span className="text-gray-900 text-right font-semibold">
                    {selectedProduct.quantity} piece(s)
                  </span>
                </div>
                {/* 🟢 NEW: Stock Level in Modal */}
                <div className="grid grid-cols-2 gap-2">
                  <span className="font-medium text-gray-700">
                    Stock Status:
                  </span>
                  <span className="text-right">
                    <div
                      className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium border ${selectedProduct.stockLevel.bgColor} ${selectedProduct.stockLevel.borderColor} ${selectedProduct.stockLevel.color}`}
                    >
                      {selectedProduct.stockLevel.icon}
                      {selectedProduct.stockLevel.label}
                    </div>
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <span className="font-medium text-gray-700">
                    Purchase Price:
                  </span>
                  <span className="text-gray-900 text-right">
                    Rs {selectedProduct.price}/-
                  </span>
                </div>
                {/* 🟢 NEW: Price Per Unit in Modal */}
                <div className="grid grid-cols-2 gap-2">
                  <span className="font-medium text-gray-700">
                    Average Price Per Unit:
                  </span>
                  <span className="text-right font-semibold text-orange-600">
                    Rs {selectedProduct.pricePerUnit}/-
                  </span>
                </div>
              </div>

              {/* Total Value */}
              <div className="bg-blue-200 border border-blue-200 rounded-lg p-3 mt-3">
                <div className="grid grid-cols-2 gap-2">
                  <span className="font-bold text-blue-900">
                    Inventory Value:
                  </span>
                  <span className="font-bold text-blue-900 text-right">
                    Rs {selectedProduct.value}/-
                  </span>
                </div>
                <div className="text-xs text-blue-700 mt-1 text-center">
                  (Accumulated inventory value)
                </div>
              </div>

              {/* Dates Section */}
              <div className="text-xs text-gray-500 italic border-t border-dashed border-gray-300 pt-3 mt-3 space-y-2">
                {/* Created Date */}
                <div className="grid grid-cols-2 gap-2">
                  <span>Created:</span>
                  <span className="text-right">
                    {formatDateTime(selectedProduct.createdAt)}
                  </span>
                </div>

                {/* Last Updated Date */}
                <div className="grid grid-cols-2 gap-2">
                  <span>Last Updated:</span>
                  <span className="text-right">
                    {formatDateTime(selectedProduct.updatedAt)}
                  </span>
                </div>
              </div>

              {/* Footer */}
              <div className="text-center border-t border-dashed border-gray-300 pt-4 text-xs text-gray-600">
                <p>This is a computer-generated record.</p>
                <p>Contains product and stock details only.</p>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="sticky bottom-0 bg-white border-t border-gray-200 rounded-b-lg p-2 print:hidden">
              <div className="flex flex-col sm:flex-row gap-2 justify-end">
                <button
                  onClick={handlePrint}
                  className="px-4 py-2 rounded bg-blue-600 cursor-pointer text-white hover:bg-blue-700 transition font-medium flex items-center justify-center gap-2"
                >
                  <span>🖨️</span>
                  <span>Print</span>
                </button>
                <button
                  onClick={handleCloseViewModal}
                  className="px-4 py-2 rounded bg-gray-600 cursor-pointer text-white hover:bg-gray-700 transition font-medium"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
