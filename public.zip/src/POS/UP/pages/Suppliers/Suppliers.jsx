import React, { useState, useMemo, useEffect } from "react";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { X } from "lucide-react";
import SearchIcon from "@mui/icons-material/Search";
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";
import VisibilityIcon from "@mui/icons-material/Visibility";
import WhatsAppIcon from "@mui/icons-material/WhatsApp";

// Utility function to get a date at midnight local time
const getLocalMidnight = (date = new Date()) => {
  const d = new Date(date);
  d.setHours(0, 0, 0, 0);
  return d;
};

/**
 * Formats an ISO date string into a user-friendly date and time string.
 */
const formatDate = (dateString) => {
  if (!dateString) return "—";
  const date = new Date(dateString);

  const dateOptions = { year: "numeric", month: "numeric", day: "numeric" };
  const timeOptions = { hour: "2-digit", minute: "2-digit", hour12: true };

  const formattedDate = date.toLocaleDateString(undefined, dateOptions);
  const formattedTime = date.toLocaleTimeString(undefined, timeOptions);

  return `${formattedDate} ${formattedTime}`;
};

// Short date format for table display
const formatShortDate = (dateString) => {
  if (!dateString) return "—";
  try {
    const date = new Date(dateString);
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const year = date.getFullYear();
    return `${day}/${month}/${year}`;
  } catch {
    return "—";
  }
};

export default function AllSuppliers() {
  const [suppliers, setSuppliers] = useState(() => {
    try {
      const raw = localStorage.getItem("all_suppliers_data");
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  });

  const [query, setQuery] = useState("");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isViewOpen, setIsViewOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [editing, setEditing] = useState(false);
  const [selectedSupplier, setSelectedSupplier] = useState(null);
  const [supplierToDelete, setSupplierToDelete] = useState(null);
  const [form, setForm] = useState({});

  // Initialize with sample data if empty
  useEffect(() => {
    const storedSuppliers = localStorage.getItem("all_suppliers_data");
    if (!storedSuppliers || JSON.parse(storedSuppliers).length === 0) {
      const sampleSuppliers = [
        {
          sNo: 1,
          supplierId: "S-001",
          name: "Ali Electronics",
          contact: "+923001234567",
          company: "Ali Electronics Ltd",
          dateAdded: new Date().toISOString(),
          whatsapp: "+923001234567",
          address: "Main Market, Lahore",
          email: "ali@electronics.com",
          status: "Active"
        },
        {
          sNo: 2,
          supplierId: "S-002",
          name: "Tech Solutions",
          contact: "+923007654321",
          company: "Tech Solutions Corp",
          dateAdded: new Date(Date.now() - 86400000).toISOString(),
          whatsapp: "+923007654321",
          address: "Commercial Area, Karachi",
          email: "info@techsolutions.com",
          status: "Active"
        }
      ];
      setSuppliers(sampleSuppliers);
    }
  }, []);

  useEffect(() => {
    localStorage.setItem("all_suppliers_data", JSON.stringify(suppliers));
  }, [suppliers]);

  const filtered = useMemo(() => {
    let arr = suppliers.slice();
    if (query.trim()) {
      const q = query.toLowerCase();
      arr = arr.filter((s) =>
        [
          s.supplierId,
          s.name,
          s.contact,
          s.company,
          s.whatsapp,
          s.email,
          s.address,
        ]
          .join(" ")
          .toLowerCase()
          .includes(q)
      );
    }
    arr.sort((a, b) => a.sNo - b.sNo);
    return arr;
  }, [suppliers, query]);

  // Toast setup
  const toastConfig = {
    position: "top-right",
    theme: "dark",
    autoClose: 2000,
  };
  const notifySuccess = (msg) => toast.success(msg, toastConfig);
  const notifyError = (msg) => toast.error(msg, toastConfig);

  const initials = (s) => {
    const nameParts = s.name.split(' ');
    if (nameParts.length >= 2) {
      return `${nameParts[0].charAt(0)}${nameParts[1].charAt(0)}`.toUpperCase();
    }
    return s.name.charAt(0).toUpperCase();
  };

  const handleOpenEdit = (supplier) => {
    setForm(supplier);
    setEditing(true);
    setIsModalOpen(true);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;

    if (name === "contact" || name === "whatsapp") {
      let val = value.replace(/[^\d+]/g, "");
      if (val && val[0] !== "+") val = "+" + val.replace(/\+/g, "");
      setForm((s) => ({ ...s, [name]: val }));
      return;
    }

    setForm((s) => ({ ...s, [name]: value }));
  };

  const handleSave = (e) => {
    e.preventDefault();

    if (!form.name?.trim()) return notifyError("Supplier name is required");
    if (!form.contact?.trim()) return notifyError("Contact number is required");
    if (!form.company?.trim()) return notifyError("Company name is required");

    const original = suppliers.find((s) => s.supplierId === form.supplierId);

    const isChanged = Object.keys(form).some(
      (key) => form[key] !== original[key]
    );

    if (!isChanged) {
      setIsModalOpen(false);
      return;
    }

    const updatedForm = {
      ...form,
      updatedAt: formatDate(new Date().toISOString()),
    };

    setSuppliers((prev) =>
      prev.map((s) => (s.supplierId === form.supplierId ? updatedForm : s))
    );
    setIsModalOpen(false);
    notifySuccess(`${form.name} updated successfully.`);
  };

  const handleDelete = (supplier) => {
    setSupplierToDelete(supplier);
    setIsDeleteModalOpen(true);
  };

  const confirmDelete = () => {
    if (!supplierToDelete) return;
    setSuppliers((prev) =>
      prev.filter((s) => s.supplierId !== supplierToDelete.supplierId)
    );
    notifySuccess(`Supplier ${supplierToDelete.name} deleted.`);
    setIsDeleteModalOpen(false);
    setSupplierToDelete(null);
  };

  const cancelDelete = () => {
    setSupplierToDelete(null);
    setIsDeleteModalOpen(false);
  };

  const handleWhatsApp = (phone) => {
    const cleanPhone = phone.replace('+', '');
    window.open(`https://wa.me/${cleanPhone}`, '_blank');
  };

  const handlePrint = () => {
    const bodyOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    window.print();
    document.body.style.overflow = bodyOverflow;
  };

  const addNewSupplier = () => {
    const newSupplierId = `S-${String(suppliers.length + 1).padStart(3, '0')}`;
    const newSupplier = {
      sNo: suppliers.length + 1,
      supplierId: newSupplierId,
      name: "",
      contact: "",
      company: "",
      dateAdded: new Date().toISOString(),
      whatsapp: "",
      address: "",
      email: "",
      status: "Active"
    };
    setForm(newSupplier);
    setEditing(false);
    setIsModalOpen(true);
  };

  const handleCreate = (e) => {
    e.preventDefault();

    if (!form.name?.trim()) return notifyError("Supplier name is required");
    if (!form.contact?.trim()) return notifyError("Contact number is required");
    if (!form.company?.trim()) return notifyError("Company name is required");

    const newSupplier = {
      ...form,
      dateAdded: new Date().toISOString(),
      createdAt: formatDate(new Date().toISOString()),
    };

    setSuppliers((prev) => [...prev, newSupplier]);
    setIsModalOpen(false);
    notifySuccess(`${form.name} created successfully.`);
  };

  return (
    <div className="p-2 min-h-screen text-white">
      <ToastContainer position="top-right" theme="dark" autoClose={2000} />

      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-white mb-2">All Suppliers</h1>
            <p className="text-white/80">
              View, edit, and manage supplier accounts.
            </p>
          </div>
          <button
            onClick={addNewSupplier}
            className="px-4 py-2 bg-green-600 hover:bg-green-700 rounded-md transition-colors cursor-pointer"
          >
            Add New Supplier
          </button>
        </div>

        {/* Filters */}
        <div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-md p-4">
          <div className="flex items-center gap-2 rounded border border-white/10 bg-white/5 px-3 py-2">
            <SearchIcon className="text-white" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search suppliers by name, company, contact..."
              className="flex-1 outline-none bg-transparent text-white placeholder-white/60"
            />
          </div>
        </div>

        {/* Table */}
        <div className="bg-white/5 backdrop-blur-lg border border-white/10 rounded-md overflow-x-auto scrollbar-hide">
          <table className="w-full text-white/90 min-w-[900px]">
            <thead className="bg-white/10 text-left text-sm">
              <tr>
                <th className="p-3">S.No</th>
                <th className="p-3">Supplier ID</th>
                <th className="p-3">Name</th>
                <th className="p-3">Contact</th>
                <th className="p-3">Company</th>
                <th className="p-3">Date Added</th>
                <th className="p-3">WhatsApp</th>
                <th className="p-3">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.length > 0 ? (
                filtered.map((s) => (
                  <tr
                    key={s.supplierId}
                    className="border-t border-white/5 hover:bg-white/5 transition"
                  >
                    <td className="p-3">{s.sNo}</td>
                    <td className="p-3">{s.supplierId}</td>
                    <td className="p-3 flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center">
                        <span className="font-medium text-white">
                          {initials(s)}
                        </span>
                      </div>
                      <div>
                        <div className="font-medium text-white">
                          {s.name}
                        </div>
                        <div className="text-sm text-white/70">{s.email}</div>
                      </div>
                    </td>
                    <td className="p-3">{s.contact}</td>
                    <td className="p-3">{s.company}</td>
                    <td className="p-3">{formatShortDate(s.dateAdded)}</td>
                    <td className="p-3">
                      <button
                        onClick={() => handleWhatsApp(s.whatsapp)}
                        className="flex items-center gap-1 p-1 rounded text-green-400 hover:text-green-300 transition-colors cursor-pointer"
                        title="Open WhatsApp"
                      >
                        <WhatsAppIcon fontSize="small" />
                        <span>Chat</span>
                      </button>
                    </td>
                    <td className="p-3 flex gap-2">
                      <button
                        title="View"
                        onClick={() => {
                          setSelectedSupplier(s);
                          setIsViewOpen(true);
                        }}
                        className="p-2 rounded bg-blue-600 text-white hover:bg-blue-500 transition-colors cursor-pointer"
                      >
                        <VisibilityIcon fontSize="small" />
                      </button>
                      <button
                        title="Edit"
                        onClick={() => handleOpenEdit(s)}
                        className="p-2 rounded bg-yellow-400 text-gray-900 hover:bg-yellow-300 transition-colors cursor-pointer"
                      >
                        <EditIcon fontSize="small" />
                      </button>
                      <button
                        title="Delete"
                        onClick={() => handleDelete(s)}
                        className="p-2 rounded bg-red-600 text-white hover:bg-red-700 transition-colors cursor-pointer"
                      >
                        <DeleteIcon fontSize="small" />
                      </button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="8" className="text-center py-6 text-white/60">
                    {suppliers.length === 0
                      ? "No suppliers added yet."
                      : "No suppliers match your search."}
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add/Edit Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 flex items-center justify-center bg-black/30 z-50 backdrop-blur-md">
          <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-lg p-6 w-full max-w-lg text-white">
            <h2 className="text-xl font-semibold mb-4">
              {editing ? `Edit Supplier: ${form.supplierId}` : 'Add New Supplier'}
            </h2>
            <form onSubmit={editing ? handleSave : handleCreate} className="space-y-3">
              <input
                name="name"
                value={form.name}
                onChange={handleChange}
                placeholder="Supplier Name"
                className="w-full p-2 rounded bg-black/30 border border-white/20 outline-none"
              />
              <input
                name="contact"
                value={form.contact}
                onChange={handleChange}
                placeholder="Contact (+92...)"
                className="w-full p-2 rounded bg-black/30 border border-white/20 outline-none"
              />
              <input
                name="company"
                value={form.company}
                onChange={handleChange}
                placeholder="Company"
                className="w-full p-2 rounded bg-black/30 border border-white/20 outline-none"
              />
              <input
                name="whatsapp"
                value={form.whatsapp}
                onChange={handleChange}
                placeholder="WhatsApp (+92...)"
                className="w-full p-2 rounded bg-black/30 border border-white/20 outline-none"
              />
              <input
                name="email"
                value={form.email}
                onChange={handleChange}
                placeholder="Email"
                type="email"
                className="w-full p-2 rounded bg-black/30 border border-white/20 outline-none"
              />
              <input
                name="address"
                value={form.address}
                onChange={handleChange}
                placeholder="Address"
                className="w-full p-2 rounded bg-black/30 border border-white/20 outline-none"
              />
              <select
                name="status"
                value={form.status}
                onChange={handleChange}
                className="w-full p-2 rounded bg-black/30 border border-white/20 outline-none"
              >
                <option className="bg-black/90">Active</option>
                <option className="bg-black/90">Inactive</option>
                <option className="bg-black/90">Suspended</option>
              </select>

              <div className="flex justify-end gap-3 pt-4">
                <button
                  type="submit"
                  className="px-4 py-2 rounded border border-white/40 bg-cyan-800/80 hover:bg-cyan-900 transition hover:cursor-pointer"
                >
                  {editing ? 'Save' : 'Create'}
                </button>
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded border border-white/40 bg-red-600 hover:bg-red-700 transition hover:cursor-pointer"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* View Modal */}
      {isViewOpen && selectedSupplier && (
        <div className="fixed inset-0 flex items-center justify-center bg-black/50 z-50 p-2 md:p-4 backdrop-blur-md print:p-0">
          <div className="bg-white text-black rounded-lg shadow-2xl w-full max-w-md mx-auto max-h-[90vh] overflow-y-auto scrollbar-hide relative font-sans text-sm border border-gray-300">
            {/* Header */}
            <div className="sticky top-0 bg-white border-b border-gray-200 rounded-t-lg p-4 z-10">
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-bold text-gray-800">Supplier Details</h2>
                <button
                  onClick={() => setIsViewOpen(false)}
                  className="p-1.5 rounded-full hover:bg-gray-100 transition cursor-pointer text-gray-500 hover:text-gray-700 print:hidden"
                >
                  <X size={20} />
                </button>
              </div>
            </div>

            {/* Content */}
            <div className="p-4 space-y-4">
              {/* Company Header */}
              <div className="text-center border-b border-dashed border-gray-300 pb-3 mb-3">
                <h2 className="text-xl font-bold tracking-wider text-gray-900">
                  ZUBI ELECTRONICS
                </h2>
                <p className="text-sm text-gray-600 mt-1">Supplier Information</p>
              </div>

              {/* Supplier Information */}
              <div className="space-y-3">
                <div className="grid grid-cols-2 gap-2">
                  <span className="font-medium text-gray-700">S.No:</span>
                  <span className="text-gray-900 text-right">{selectedSupplier.sNo}</span>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <span className="font-medium text-gray-700">Supplier ID:</span>
                  <span className="text-gray-900 text-right">{selectedSupplier.supplierId}</span>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <span className="font-medium text-gray-700">Name:</span>
                  <span className="text-gray-900 text-right">{selectedSupplier.name}</span>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <span className="font-medium text-gray-700">Contact:</span>
                  <span className="text-gray-900 text-right">{selectedSupplier.contact}</span>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <span className="font-medium text-gray-700">Company:</span>
                  <span className="text-gray-900 text-right">{selectedSupplier.company}</span>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <span className="font-medium text-gray-700">WhatsApp:</span>
                  <span className="text-gray-900 text-right">{selectedSupplier.whatsapp}</span>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <span className="font-medium text-gray-700">Email:</span>
                  <span className="text-gray-900 text-right">{selectedSupplier.email || "—"}</span>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <span className="font-medium text-gray-700">Address:</span>
                  <span className="text-gray-900 text-right">{selectedSupplier.address || "—"}</span>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <span className="font-medium text-gray-700">Status:</span>
                  <span className={`text-right font-medium ${
                    selectedSupplier.status === 'Active' ? 'text-green-600' :
                    selectedSupplier.status === 'Inactive' ? 'text-yellow-600' :
                    'text-red-600'
                  }`}>
                    {selectedSupplier.status}
                  </span>
                </div>
              </div>

              {/* Dates Section */}
              <div className="border-t border-dashed border-gray-300 pt-3 mt-3 space-y-2">
                <div className="grid grid-cols-2 gap-2">
                  <span className="font-medium text-gray-700">Date Added:</span>
                  <span className="text-gray-900 text-right">{formatDate(selectedSupplier.dateAdded)}</span>
                </div>
                {selectedSupplier.updatedAt && (
                  <div className="grid grid-cols-2 gap-2">
                    <span className="font-medium text-gray-700">Last Updated:</span>
                    <span className="text-gray-900 text-right">{selectedSupplier.updatedAt}</span>
                  </div>
                )}
                {selectedSupplier.createdAt && (
                  <div className="grid grid-cols-2 gap-2">
                    <span className="font-medium text-gray-700">Created At:</span>
                    <span className="text-gray-900 text-right">{selectedSupplier.createdAt}</span>
                  </div>
                )}
              </div>

              {/* Footer */}
              <div className="text-center border-t border-dashed border-gray-300 pt-4 text-xs text-gray-600">
                <p>This is a computer-generated supplier record.</p>
                <p>Contains business and contact information only.</p>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="sticky bottom-0 bg-white border-t border-gray-200 rounded-b-lg p-4 print:hidden">
              <div className="flex flex-col sm:flex-row gap-2 justify-end">
                <button
                  onClick={() => handleWhatsApp(selectedSupplier.whatsapp)}
                  className="px-4 py-2 rounded bg-green-600 cursor-pointer text-white hover:bg-green-700 transition font-medium flex items-center justify-center gap-2"
                >
                  <WhatsAppIcon />
                  <span>WhatsApp</span>
                </button>
                <button
                  onClick={handlePrint}
                  className="px-4 py-2 rounded bg-blue-600 cursor-pointer text-white hover:bg-blue-700 transition font-medium flex items-center justify-center gap-2"
                >
                  <span>🖨️</span>
                  <span>Print</span>
                </button>
                <button
                  onClick={() => setIsViewOpen(false)}
                  className="px-4 py-2 rounded bg-gray-600 cursor-pointer text-white hover:bg-gray-700 transition font-medium"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Delete Modal */}
      {isDeleteModalOpen && supplierToDelete && (
        <div className="fixed inset-0 flex items-center justify-center bg-black/30 z-50 backdrop-blur-md">
          <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-lg p-6 w-full max-w-sm text-white">
            <h2 className="text-xl font-semibold mb-4">Confirm Delete</h2>
            <p className="mb-4">
              Are you sure you want to delete{" "}
              <strong>{supplierToDelete.name}</strong>
              ?
            </p>
            <div className="flex justify-end gap-3">
              <button
                onClick={cancelDelete}
                className="px-4 py-2 rounded border border-white/40 bg-cyan-800/80 hover:bg-cyan-900 hover:cursor-pointer transition"
              >
                Cancel
              </button>
              <button
                onClick={confirmDelete}
                className="px-4 py-2 rounded border border-white/40 bg-red-600 hover:bg-red-700 hover:cursor-pointer transition"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}