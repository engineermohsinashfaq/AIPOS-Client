import React from 'react'

const InstallmentManagement = () => {
  return (
    <div>InstallmentManagement</div>
  )
}

export default InstallmentManagement