import React from 'react'

const Developers = () => {
  return (
    <div>Developers</div>
  )
}

export default Developers