import React from 'react'
import UnderDevelopment from "../UnderDevelopment/UnderDevelopment"
const BikesEscoters = () => {
  return (
    <UnderDevelopment/>
  )
}

export default BikesEscoters