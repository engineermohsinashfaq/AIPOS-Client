import React from 'react'
import UnderDevelopment from "../UnderDevelopment/UnderDevelopment"

const OthersAccessories = () => {
  return (
    <UnderDevelopment/>
  )
}

export default OthersAccessories