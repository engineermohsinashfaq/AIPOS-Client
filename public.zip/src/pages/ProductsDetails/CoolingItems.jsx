import React from 'react'
import UnderDevelopment from "../UnderDevelopment/UnderDevelopment"

const CoolingItems = () => {
  return (
    <UnderDevelopment/>
  )
}

export default CoolingItems